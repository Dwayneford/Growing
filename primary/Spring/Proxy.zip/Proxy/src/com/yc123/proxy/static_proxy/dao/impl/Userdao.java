package com.yc123.proxy.static_proxy.dao.impl;

import com.yc123.proxy.static_proxy.dao.IUser;

public class Userdao implements IUser {

	@Override
	public void add() {
		System.out.println("添加方法");

	}

	@Override
	public void delete() {
		System.out.println("删除方法");

	}

	@Override
	public void update() {
		System.out.println("修改方法");

	}

	@Override
	public Object query() {
		System.out.println("查询方法");
		return null;
	}

}
