package com.yc123.proxy.dynamic_proxy.dao;

public interface IUser {

	public void add();
	public void delete();
	public void update();
	public Object query();
	
}
