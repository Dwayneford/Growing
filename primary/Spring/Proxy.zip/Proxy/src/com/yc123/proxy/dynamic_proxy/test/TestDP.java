package com.yc123.proxy.dynamic_proxy.test;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yc123.proxy.dynamic_proxy.aspect.UserDProxy;
import com.yc123.proxy.dynamic_proxy.dao.IUser;
import com.yc123.proxy.dynamic_proxy.dao.impl.Userdao;


public class TestDP {

	public static void main(String[] args) {
		System.out.println("原始方法==>");
		Userdao ud = new Userdao();
		ud.add();
		
		System.out.println();
		System.out.println("代理方法==>");
		IUser iu = (IUser) UserDProxy.getProxyInstance(new Userdao());
		iu.add();
		iu.delete();
		
		System.out.println();
		System.out.println("spring获取对象==>");
		BeanFactory bf = new ClassPathXmlApplicationContext("applicationContext.xml");
		Userdao userdao = bf.getBean("userDao",Userdao.class);
		userdao.add();
		
	
	}
	
}
