package com.yc123.proxy.static_proxy.test;

import com.yc123.proxy.static_proxy.aspect.UserProxy;
import com.yc123.proxy.static_proxy.dao.impl.Userdao;

public class Test {

	public static void main(String[] args) {
		UserProxy up = new UserProxy(new Userdao());
		//代理中修改后的方法
		System.out.println("--代理中修改后的方法:");
		up.add();
		System.out.println("--代理中原始方法:");
		up.delete();
	}
}
