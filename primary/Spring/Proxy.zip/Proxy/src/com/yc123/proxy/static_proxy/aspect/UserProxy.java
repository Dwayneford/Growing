package com.yc123.proxy.static_proxy.aspect;

import com.yc123.proxy.static_proxy.dao.IUser;

public class UserProxy implements IUser {

	//目标对象
	private IUser iuser ;
	//通过构造方法传入目标对象
	public UserProxy(IUser iuser) {
		super();
		this.iuser = iuser;
	}	
	
	@Override
	public void add() {
		
		//静态代理方法，调用被代理的方法的同时，可对其添加非核心逻辑
		
		System.out.println("准备开始添加方法");
		iuser.add();
		System.out.println("添加方法结束");
	}



	@Override
	public void delete() {
		iuser.delete();

	}

	@Override
	public void update() {
		iuser.update();

	}

	@Override
	public Object query() {
		iuser.query();
		return null;
	}

}
