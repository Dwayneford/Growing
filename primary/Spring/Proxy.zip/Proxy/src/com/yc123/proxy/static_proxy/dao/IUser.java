package com.yc123.proxy.static_proxy.dao;

public interface IUser {

	public void add();
	public void delete();
	public void update();
	public Object query();
	
}
