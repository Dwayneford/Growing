package com.yc123.spring.aspect;

import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;

public class Notice {
	//写通知  前置通知
	public void methodBegin(JoinPoint joinPint){
		
		//获取签名参数 ：joinPiint传递的参数形式
		Signature signature = joinPint.getSignature();
		//方法传递的实际参数
		Object[] args = joinPint.getArgs();
		
		System.out.println("[前置通知] 执行了方法：["+signature.getName()+"]参数列表为："+Arrays.asList(args));
	} 
	
	//返回通知
	public void methodReturn(JoinPoint joinPint,Object resutl){
		//获取签名参数 ：joinPiint传递的参数形式
		Signature signature = joinPint.getSignature();
		String methodName = signature.getName();
		
		System.out.println("[返回通知] 执行了方法：["+methodName+"]返回结果为："+resutl);
	}
	
	//返回异常通知
	public void methodThrow(JoinPoint joinPint,ArithmeticException throwable){
		//获取签名参数 ：joinPiint传递的参数形式
		String methodName = joinPint.getSignature().getName();
		
		String message = throwable.getMessage();
		
		System.out.println("[异常通知] 执行了方法：["+methodName+"]返回异常信息为："+message);
	}
	//后置通知
	public void methodFinallEnd(JoinPoint joinPint){
		//获取签名参数 ：joinPiint传递的参数形式
		String methodName = joinPint.getSignature().getName();
				
		System.out.println("[后置通知] 执行了方法：["+methodName+"]");
	}
	
	//环绕通知
	public Object myArround(ProceedingJoinPoint joinPoint){
		//获取签名参数 ：joinPiint传递的参数形式
		String methodName = joinPoint.getSignature().getName();
				
		//获取参数
		Object[] args = joinPoint.getArgs();
		
		System.out.println("[环绕通知] 执行了方法：["+methodName+"]开始执行的参数为："+Arrays.asList(args));
		
		Object resutl = null;
		
		try {
			resutl = joinPoint.proceed();
			//执行result表示 方法执行 结束
			System.out.println("[环绕通知] 执行了方法：["+methodName+"]正常结束，结果为："+resutl+"【环绕通知】");
			
		} catch (Throwable e) {
			System.out.println("[环绕通知] 执行了方法：["+methodName+"]抛出异常，异常信息为："+e.getMessage()+"【环绕通知】");
		}finally{
			System.out.println("[环绕通知] 执行了方法：["+methodName+"]最终结束");
		}
		return resutl;
	}
}

