package com.yc123.spring.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yc123.spring.service.IMathOperation;
import com.yc123.spring.service.impl.MathOperationIMPL;

public class Test {
	public static void main(String[] args) {
		BeanFactory bf = new ClassPathXmlApplicationContext("applicationContext.xml");
		IMathOperation im = bf.getBean("mathIMPL",MathOperationIMPL.class);
		im.add(15, 3);
		im.divide(15, 3);
		im.divide(15, 0);
	}
	
	
}
