package com.yc123.spring.service.impl;

import com.yc123.spring.service.IMathOperation;

public class MathOperationIMPL implements IMathOperation {

	@Override
	public int add(int i, int j) {
		int result = j+j;
		System.out.println("加法:"+result);
		return result;
	}

	@Override
	public int subtract(int i, int j) {
		int result = j-j;
		System.out.println("减法:"+result);
		return result;
	}

	@Override
	public int multiply(int i, int j) {
		int result = j*j;
		System.out.println("乘法:"+result);
		return result;
	}

	@Override
	public int divide(int i, int j) {
		int result = j/j;
		System.out.println("除法:"+result);
		return result;
	}

}
