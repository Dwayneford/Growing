package com.yc123.spring.service;

public interface IMathOperation {

	public int add(int i , int j);
	public int subtract(int i , int j);
	public int multiply (int i , int j);
	public int divide(int i , int j);
}
