package com.yc123.spring.test_;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yc123.spring.test_.impl.Cat;
import com.yc123.spring.test_.impl.TypeTest;

public class Test_01 {

	public static void main(String[] args) {
		//读取配置文件注入IOC容器
		BeanFactory factory = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		ApplicationContext factory2 = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//获取bean的实例，面向接口编程，强制转换成接口类型
		Animal animal = (Animal) factory.getBean("kitty");
		animal.sayHello();
		Cat cat = (Cat) factory.getBean("cat");
		cat.sayTell();
		System.out.println(cat.getStr());
		
		System.out.println("获取属性值");
		TypeTest tt = (TypeTest) factory.getBean("type");
		System.out.println(tt.getStr());
		System.out.println(tt.getList());
		System.out.println(tt.getSet());
		System.out.println(tt.getMap());
		System.out.println(tt.getProp());
		
		
//		Animal animal2 = (Animal) factory2.getBean("kitty");
//		animal2.sayHello();
	}
}
