package com.yc123.spring.test_;

public interface Animal {

	void sayHello();
	
}
