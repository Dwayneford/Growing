package com.yc123.spring.test_.impl;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class TypeTest {
	private String str ;
	private List list ;
	private Set set ;
	private Map map;
	private Properties prop ;
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public Set getSet() {
		return set;
	}
	public void setSet(Set set) {
		this.set = set;
	}
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	public Properties getProp() {
		return prop;
	}
	public void setProp(Properties prop) {
		this.prop = prop;
	}
	public TypeTest() {
		super();
	}
	public TypeTest(String str, List list, Set set, Map map, Properties prop) {
		super();
		this.str = str;
		this.list = list;
		this.set = set;
		this.map = map;
		this.prop = prop;
	}
	
}
