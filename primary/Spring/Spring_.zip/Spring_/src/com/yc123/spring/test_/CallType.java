package com.yc123.spring.test_;

public interface CallType {

	String call() ;
}
