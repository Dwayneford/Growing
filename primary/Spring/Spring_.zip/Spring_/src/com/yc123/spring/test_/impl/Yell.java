package com.yc123.spring.test_.impl;

import com.yc123.spring.test_.CallType;

public class Yell implements CallType{

	@Override
	public String call() {
		// TODO Auto-generated method stub
		return "小猫咪咪叫";
	}

}
