package com.yc123.spring.test_.impl;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.yc123.spring.test_.Animal;
import com.yc123.spring.test_.CallType;

public class Cat implements Animal{

	private CallType call ;
	private Yell yell;
	
	private String str ;
	private List list ;
	private Set set ;
	private Map map;
	private Properties prop ;
	
	
	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public Set getSet() {
		return set;
	}

	public void setSet(Set set) {
		this.set = set;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	public Properties getProp() {
		return prop;
	}

	public void setProp(Properties prop) {
		this.prop = prop;
	}

	public Yell getYell() {
		return yell;
	}

	public void setYell(Yell yell) {
		this.yell = yell;
	}

	public CallType getCall() {
		return call;
	}

	public void setCall(CallType call) {
		this.call = call;
	}

	public Cat() {
		super();
	}

	@Override
	public void sayHello() {
		System.out.println(call.call());
		
	}
	
	public void sayTell(){
		System.out.println(yell.call());
	}
	
}
