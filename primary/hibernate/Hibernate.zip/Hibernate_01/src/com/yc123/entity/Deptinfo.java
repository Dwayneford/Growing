package com.yc123.entity;

import java.util.HashSet;
import java.util.Set;

/**
 * Deptinfo entity. @author MyEclipse Persistence Tools
 */

public class Deptinfo implements java.io.Serializable {

	// Fields

	private Integer deptId;
	private String deptName;
	private String remark;
	private Set empinfos = new HashSet(0);

	// Constructors

	/** default constructor */
	public Deptinfo() {
	}

	/** minimal constructor */
	public Deptinfo(String deptName) {
		this.deptName = deptName;
	}

	/** full constructor */
	public Deptinfo(String deptName, String remark, Set empinfos) {
		this.deptName = deptName;
		this.remark = remark;
		this.empinfos = empinfos;
	}

	// Property accessors

	public Integer getDeptId() {
		return this.deptId;
	}

	public void setDeptId(Integer deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return this.deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Set getEmpinfos() {
		return this.empinfos;
	}

	public void setEmpinfos(Set empinfos) {
		this.empinfos = empinfos;
	}

	@Override
	public String toString() {
		return "Deptinfo [deptId=" + deptId + ", deptName=" + deptName + ", remark=" + remark + "]";
	}



}