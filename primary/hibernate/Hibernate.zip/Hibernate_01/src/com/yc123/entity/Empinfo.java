package com.yc123.entity;

/**
 * Empinfo entity. @author MyEclipse Persistence Tools
 */

public class Empinfo implements java.io.Serializable {

	// Fields

	private Integer empId;
	private Deptinfo deptinfo;
	private String name;
	private String sex;
	private Integer age;
	private Double salary;
	private String address;

	// Constructors

	/** default constructor */
	public Empinfo() {
	}

	/** minimal constructor */
	public Empinfo(String name, String sex, Integer age, Double salary) {
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.salary = salary;
	}

	/** full constructor */
	public Empinfo(Deptinfo deptinfo, String name, String sex, Integer age, Double salary, String address) {
		this.deptinfo = deptinfo;
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.salary = salary;
		this.address = address;
	}

	// Property accessors

	public Integer getEmpId() {
		return this.empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public Deptinfo getDeptinfo() {
		return this.deptinfo;
	}

	public void setDeptinfo(Deptinfo deptinfo) {
		this.deptinfo = deptinfo;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Double getSalary() {
		return this.salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Empinfo [empId=" + empId + ", name=" + name + ", sex=" + sex + ", age=" + age + ", salary=" + salary
				+ ", address=" + address + "]";
	}

}