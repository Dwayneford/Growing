package com.yc123.util;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BaseDao {
	
	//�������� sessionFactory
	private static SessionFactory factory;
	//��ʼ�� ��ȡhibernate�������
	static{
		Configuration cfg = new Configuration().configure();
		//��ȡ���������
		factory = cfg.buildSessionFactory();
	}
		
	/**
	 * ���ӷ���
	 */
	public Boolean commonAdd(Object obj){
		//����session
		Session session = factory.openSession();
		//��������
		Transaction ts = session.beginTransaction();
		
		try {
			session.save(obj);
			
			ts.commit();
			
			return true;
		} catch (Exception e) {
			ts.rollback();
		}finally{
			session.close();
		}
		return false;
	} 
		
	
	public Boolean commonUpdate(Object obj){
		//����session
		Session session = factory.openSession();
		//��������
		Transaction ts = session.beginTransaction();
		
		try {
			session.update(obj);
			ts.commit();
			
			return true;
		} catch (Exception e) {
			ts.rollback();
		}finally{
			session.close();
		}
		return false;
	} 
	
	public Boolean commonDelete(Object obj){
		//����session
		Session session = factory.openSession();
		//��������
		Transaction ts = session.beginTransaction();
		
		try {
			session.delete(obj);
			ts.commit();
			return true;
		} catch (Exception e) {
			ts.rollback();
		}finally{
			session.close();
		}
		return false;
	}
	/**
	 * �б���ѯ����
	 * @param hql
	 * @param parms
	 * @return
	 */
	public List commonQuery(String hql,Object ...parms){
		//����session
		Session session = factory.openSession();
		Query query = session.createQuery(hql);
		//�ж��Ƿ��в��� ��ֵ
		if(parms.length>0){
			for (int i = 0; i < parms.length; i++) {
				query.setParameter(i, parms[i]);
			}
		}
		//����
		return query.list();
	}
	
	//get() load()
	public Object getObj(Class cls, int id){
		
		 Session session = factory.openSession();
		 Object obj = session.get(cls, id);
		 session.close();
		 return obj;
	}
	
	/**
	 * ��ҳ��ѯ
	 */
	public List commonQueryPage(String hql,int pageSeiz,int pageNo,Object ...parms){
		//����session
		Session session = factory.openSession();
		Query query = session.createQuery(hql);
		//��ֵ....
		
		//���÷�ҳ����
		query.setFirstResult((pageNo-1)*pageSeiz);
		query.setMaxResults(pageSeiz);
		
		List list =  query.list();
		
		return list;
		
	}
	
}
