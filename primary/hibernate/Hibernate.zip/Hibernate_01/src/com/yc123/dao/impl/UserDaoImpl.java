package com.yc123.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import com.yc123.entity.Userinfo;

public class UserDaoImpl {

	private static SessionFactory factory=null;
	static {
		Configuration cfg = new Configuration().configure();
		factory = cfg.buildSessionFactory();
	}
	
	
	/*ʹ��hqlд��ѯ����
		ͨ���������Ƹ�������ֵ
	 * */
	@Test
	public void queryList(){
		
		String hql ="from Userinfo ui where ui.name=:une and ui.sex=:usx";
		Session session = factory.openSession();
		Query query = session.createQuery(hql);
		
		
		query.setString("une", "С��");
		query.setString("usx", "��");
		
		List<Userinfo> list =	query.list();
		for (Userinfo userinfo : list) {
			System.out.println(userinfo.toString());
		}
	}
	
	
	/*ͨ��λ�ø�������ֵ*/
	@Test
	public void queryList2(){
		
		String hql ="from Userinfo ui where ui.name=? and ui.sex=?";
		Session session = factory.openSession();
		Query query = session.createQuery(hql);
		
		query.setString(0, "С��");
		query.setString(1, "��");
		
		List<Userinfo> list =	query.list();
		for (Userinfo userinfo : list) {
			System.out.println(userinfo.toString());
		}
	}
	
	/*ͨ�������������ֵ
	 * 
	 * 
	 *  * private Integer id;
	private String name;
	private String password;
	private String sex;
	private Integer age;
	private Date birthday;
	 * */
	@Test
	public void queryList3(){
		
		Userinfo user = new Userinfo();
		user.setName("С3");
		user.setSex("m");
		user.setAge(20);
		
		/*
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("name", "С3");*/
		
		
		String hql ="from Userinfo ui where ui.name=:name and ui.sex=:sex and ui.age=:age";
		Session session = factory.openSession();
		Query query = session.createQuery(hql);
		//��ֵ
		query.setProperties(user);
		
		//��ҳ���� �ۺϺ���.....
		
		List<Userinfo> list = query.list();
		for (Userinfo userinfo : list) {
			System.out.println(userinfo.toString());
		}
	}
}
