package com.sat.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sat.dao.StudentDao;
import com.sat.dao.WebsitesDao;
import com.sat.entity.Student;
import com.sat.entity.Websites;

@Component("stuService")
public class StuService {

	private StudentDao stuDao ;
	private WebsitesDao wsDao ;
	public StudentDao getStuDao() {
		return stuDao;
	}
	@Resource(name="stuDao")
	public void setStuDao(StudentDao stuDao) {
		this.stuDao = stuDao;
	}
	public WebsitesDao getWsDao() {
		return wsDao;
	}
	@Resource(name="wsDao")
	public void setWsDao(WebsitesDao wsDao) {
		this.wsDao = wsDao;
	}
	//默认值即为后面的值
	@Transactional(propagation=Propagation.REQUIRED)
	public void add(Student stu ){
		this.stuDao.add(stu);
		this.wsDao.add(new Websites("sat", "service", 34, "事务"));
		
	}
}
