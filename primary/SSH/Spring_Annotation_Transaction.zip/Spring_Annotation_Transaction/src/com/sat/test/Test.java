package com.sat.test;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sat.entity.Student;
import com.sat.service.StuService;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		StuService stuService = (StuService) ctx.getBean("stuService");
		stuService.add(new Student("框架融合", 21, new Date()));
		
	}
	
}
