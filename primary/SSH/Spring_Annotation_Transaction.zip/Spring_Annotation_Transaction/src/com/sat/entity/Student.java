package com.sat.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "student", catalog = "mysql2019815")

public class Student implements java.io.Serializable {

	// Fields

	private Integer stuNo;
	private String stuName;
	private Integer stuAge;
	private Date stuBrith;

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(String stuName, Integer stuAge, Date stuBrith) {
		this.stuName = stuName;
		this.stuAge = stuAge;
		this.stuBrith = stuBrith;
	}

	// Property accessors
	@Id
	@GeneratedValue

	@Column(name = "stu_no", unique = true, nullable = false)

	public Integer getStuNo() {
		return this.stuNo;
	}

	public void setStuNo(Integer stuNo) {
		this.stuNo = stuNo;
	}

	@Column(name = "stu_name", length = 15)

	public String getStuName() {
		return this.stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	@Column(name = "stu_age")

	public Integer getStuAge() {
		return this.stuAge;
	}

	public void setStuAge(Integer stuAge) {
		this.stuAge = stuAge;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "stu_brith", length = 10)

	public Date getStuBrith() {
		return this.stuBrith;
	}

	public void setStuBrith(Date stuBrith) {
		this.stuBrith = stuBrith;
	}

}