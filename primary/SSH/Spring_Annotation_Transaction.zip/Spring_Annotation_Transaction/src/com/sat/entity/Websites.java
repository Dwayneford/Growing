package com.sat.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Websites entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "websites", catalog = "mysql2019815")

public class Websites implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private String url;
	private Integer alexa;
	private String country;

	// Constructors

	/** default constructor */
	public Websites() {
	}

	/** full constructor */
	public Websites(String name, String url, Integer alexa, String country) {
		this.name = name;
		this.url = url;
		this.alexa = alexa;
		this.country = country;
	}

	// Property accessors
	@Id
	@GeneratedValue

	@Column(name = "id", unique = true, nullable = false)

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "name", nullable = false)

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "url", nullable = false)

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "alexa", nullable = false)

	public Integer getAlexa() {
		return this.alexa;
	}

	public void setAlexa(Integer alexa) {
		this.alexa = alexa;
	}

	@Column(name = "country", nullable = false)

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}