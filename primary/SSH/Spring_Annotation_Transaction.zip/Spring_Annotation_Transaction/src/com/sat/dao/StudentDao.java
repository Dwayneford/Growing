package com.sat.dao;

import com.sat.entity.Student;

public interface StudentDao {

	public void add(Student stu);
	
}
