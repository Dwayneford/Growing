package com.sat.dao;


import com.sat.entity.Websites;

public interface WebsitesDao {

	public void add(Websites ws);
}
