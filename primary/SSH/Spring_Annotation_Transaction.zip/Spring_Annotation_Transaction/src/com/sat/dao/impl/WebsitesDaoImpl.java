package com.sat.dao.impl;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import com.sat.dao.WebsitesDao;
import com.sat.entity.Websites;
@Component("wsDao")
public class WebsitesDaoImpl implements WebsitesDao{
	@Resource
	private SessionFactory sessionFactory ;
	@Override
	public void add(Websites ws) {
		sessionFactory.getCurrentSession().save(ws);
		System.out.println("添加了ws对象");
	}
//	@Override
//	public void add(Websites ws) {
//		System.out.println("添加了ws对象");
//		
//	}
	
	//有了@Resource，set和get可以注释掉
//	public SessionFactory getSessionFactory() {
//		return sessionFactory;
//	}
//	
//	public void setSessionFactory(SessionFactory sessionFactory) {
//		this.sessionFactory = sessionFactory;
//	}

}
