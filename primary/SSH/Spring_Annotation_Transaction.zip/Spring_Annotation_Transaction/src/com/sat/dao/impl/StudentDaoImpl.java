package com.sat.dao.impl;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import com.sat.dao.StudentDao;
import com.sat.entity.Student;
@Component("stuDao")
public class StudentDaoImpl implements StudentDao{
	
	private SessionFactory sessionFactory ;
	@Override
	public void add(Student stu) {
		sessionFactory.getCurrentSession().save(stu);
		
	}
	
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	@Resource
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

}
