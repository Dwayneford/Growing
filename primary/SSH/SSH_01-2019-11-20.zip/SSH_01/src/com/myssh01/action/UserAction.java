package com.myssh01.action;

import java.util.List;

import com.myssh01.entity.User;
import com.myssh01.service.IUserService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport{

	//定义需要使用的参数
	/*
	 * 私有属性，用于接收前端传来的数据
	 */
	private User userEnt ;
	private IUserService userService ;
	
	public User getUserEnt() {
		return userEnt;
	}
	public void setUserEnt(User userEnt) {
		this.userEnt = userEnt;
	}
	public IUserService getUserService() {
		return userService;
	}
	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	
	/**
	 * 前端的请求方法
	 */
	public String queryUserList(){
		List<User> userlist = userService.queryUser();
		if (userlist != null) {
			ActionContext.getContext().put("userlist", userlist);
			return SUCCESS;
		}else{
			return ERROR ;
		}
		
	}
	
	
	
}
