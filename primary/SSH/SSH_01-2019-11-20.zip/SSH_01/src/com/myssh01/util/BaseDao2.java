package com.myssh01.util;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.myssh01.entity.User;

public class BaseDao2 extends JdbcTemplate{

	//查询用户方法
		public List<User> commonQueryUser(){
			String hql = "from User";
			super.execute(hql);
			return null ;
		}
	
}
