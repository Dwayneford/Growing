package com.myssh01.util;

import java.util.List;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.myssh01.entity.User;
/*
 * 公共dao类，继承hibernateTemplate或者是JdbcTemplate
 * 普通dao类的父类
 */
public class BaseDao extends HibernateTemplate{

	//查询用户方法
	public List<User> commonQueryUser(){
		String hql = "from User";
		return (List<User>) super.find(hql) ;
	}
	
}
