package com.myssh01.service.impl;

import java.util.List;

import com.myssh01.dao.IUser;
import com.myssh01.entity.User;
import com.myssh01.service.IUserService;

public class UserServiceImpl implements IUserService {
	//获得dao层接口对象
	private IUser iuser ;	
	public IUser getIuser() {
		return iuser;
	}
	public void setIuser(IUser iuser) {
		this.iuser = iuser;
	}
	/**
	 * 业务层的实现方法
	 */
	@Override
	public List<User> queryUser() {

		return iuser.queryUser();
	}

}
