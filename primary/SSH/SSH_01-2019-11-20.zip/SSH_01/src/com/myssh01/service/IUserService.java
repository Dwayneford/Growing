package com.myssh01.service;

import java.util.List;

import com.myssh01.entity.User;

public interface IUserService {

	public List<User> queryUser();
	
}
