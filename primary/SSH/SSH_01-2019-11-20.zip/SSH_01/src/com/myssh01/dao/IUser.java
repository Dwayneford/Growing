package com.myssh01.dao;

import java.util.List;

import com.myssh01.entity.User;

public interface IUser {
	public List<User> queryUser();
}
