package com.myssh01.dao.impl;

import java.util.List;

import com.myssh01.dao.IUser;
import com.myssh01.entity.User;
import com.myssh01.util.BaseDao;

public class UserDao extends BaseDao implements IUser {

	@Override
	public List<User> queryUser() {
		
		return super.commonQueryUser();
	}

}
