package com.myssh01.entity;
// default package

import java.sql.Timestamp;


/**
 * User entity. @author MyEclipse Persistence Tools
 */

public class User  implements java.io.Serializable {


    // Fields    

     private Integer rid;
     private String loginName;
     private String password;
     private String UName;
     private String UPost;
     private String UPhone;
     private Integer UParentId;
     private Integer UStorageId;
     private Integer status;
     private Timestamp createTime;
     private String URemark;


    // Constructors

    /** default constructor */
    public User() {
    }

	/** minimal constructor */
    public User(String loginName, String password, Integer UStorageId, Integer status) {
        this.loginName = loginName;
        this.password = password;
        this.UStorageId = UStorageId;
        this.status = status;
    }
    
    /** full constructor */
    public User(String loginName, String password, String UName, String UPost, String UPhone, Integer UParentId, Integer UStorageId, Integer status, Timestamp createTime, String URemark) {
        this.loginName = loginName;
        this.password = password;
        this.UName = UName;
        this.UPost = UPost;
        this.UPhone = UPhone;
        this.UParentId = UParentId;
        this.UStorageId = UStorageId;
        this.status = status;
        this.createTime = createTime;
        this.URemark = URemark;
    }

   
    // Property accessors

    public Integer getRid() {
        return this.rid;
    }
    
    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getLoginName() {
        return this.loginName;
    }
    
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public String getUName() {
        return this.UName;
    }
    
    public void setUName(String UName) {
        this.UName = UName;
    }

    public String getUPost() {
        return this.UPost;
    }
    
    public void setUPost(String UPost) {
        this.UPost = UPost;
    }

    public String getUPhone() {
        return this.UPhone;
    }
    
    public void setUPhone(String UPhone) {
        this.UPhone = UPhone;
    }

    public Integer getUParentId() {
        return this.UParentId;
    }
    
    public void setUParentId(Integer UParentId) {
        this.UParentId = UParentId;
    }

    public Integer getUStorageId() {
        return this.UStorageId;
    }
    
    public void setUStorageId(Integer UStorageId) {
        this.UStorageId = UStorageId;
    }

    public Integer getStatus() {
        return this.status;
    }
    
    public void setStatus(Integer status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return this.createTime;
    }
    
    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getURemark() {
        return this.URemark;
    }
    
    public void setURemark(String URemark) {
        this.URemark = URemark;
    }
   








}