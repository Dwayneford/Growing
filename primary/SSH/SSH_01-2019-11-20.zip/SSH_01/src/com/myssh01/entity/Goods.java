package com.myssh01.entity;
// default package



/**
 * Goods entity. @author MyEclipse Persistence Tools
 */

public class Goods  implements java.io.Serializable {


    // Fields    

     private Integer rid;
     private String goodsName;
     private Float price;
     private String remarks;


    // Constructors

    /** default constructor */
    public Goods() {
    }

    
    /** full constructor */
    public Goods(String goodsName, Float price, String remarks) {
        this.goodsName = goodsName;
        this.price = price;
        this.remarks = remarks;
    }

   
    // Property accessors

    public Integer getRid() {
        return this.rid;
    }
    
    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getGoodsName() {
        return this.goodsName;
    }
    
    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public Float getPrice() {
        return this.price;
    }
    
    public void setPrice(Float price) {
        this.price = price;
    }

    public String getRemarks() {
        return this.remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
   








}