package com.yc123.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport{
	//�����
	private String loginName;
	private String loginPwd;
	
	/**
	 * Ĭ��ִ�з���
	 */
	@Override
	public String execute() throws Exception {
		//super.execute()
		return SUCCESS;
	}
	/**
	 * ��¼����
	 * @return
	 */
	public String login(){
		System.out.println("sss");
		//����������� ��ҳ����ʾֵ
		ActionContext.getContext().put("loginName", loginName);
		ActionContext.getContext().put("loginPwd", loginPwd);
		/*session
			ActionContext.getContext().getSession().put(key, value)
		  application
			ActionContext.getContext().getApplication().put(key, value)
		*/
		//ʹ��ԭ�� servlet �������
		HttpServletRequest request = ServletActionContext.getRequest();
		
		HttpSession session = request.getSession();
		 
		ServletContext application = ServletActionContext.getServletContext();
		
		System.out.println("��¼�ɹ�������"+loginName+"=="+loginPwd);
		return "ok";
	}
	/**
	 * �޸��û���Ϣ
	 * @return
	 */
	public String updateUser(){
		
		//ȷ�� ���ݵĲ���
		ActionContext.getContext().put("upUserId", 1001);
		return "updateUser";
		
	}
	
	

	/**
	 * �޸��û���Ϣ
	 * @return
	 */
	public String logForUser(){
		//ȷ�� ���ݵĲ���
		ActionContext.getContext().put("upUserId", 1001);
		ActionContext.getContext().put("loginName", "���»�");
		ActionContext.getContext().put("loginPwd", "2015156");
		
		return "logForUser";
		
	}
	
	/**
	 * �˳�ϵͳ
	 * @return
	 */
	public String exist(){
		//ʹ��ԭ�� servlet �������
		HttpServletRequest request = ServletActionContext.getRequest();
				
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "exist";
	}
	
	//������get/set ����
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
}
