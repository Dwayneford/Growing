package com.jjfk.dao;

import java.awt.print.Pageable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jjfk.entity.Goods_table;
import com.jjfk.util.PageModel;


public interface IGoods {
	/**
	 * �б���ѯ
	 * @param goods_type
	 * @param goods_price
	 * @return
	 */
	public List<Goods_table> queryGoods(String goods_type,double goods_price);
	/**
	 * �����޸�
	 * @param gdEnt
	 * @return
	 */
	public boolean saveOrUpdate(Goods_table gdEnt);

	/**
	 * ͨ��id��ѯʵ�����
	 * @param goodId
	 * @return
	 */
	public Goods_table getGoodsInfo(int goodId);
	
	/**
	 * ��ҳ������ѯ
	 */
	public int countRow(Map<String, Object> map);
	
	/**
	 * ��ѯÿҳ��ʾ������
	 */
	public PageModel<Goods_table> queryPage(Map<String, Object> map);
	
	public ArrayList<Goods_table> layPage(Map<String, Object> map);
	
}
