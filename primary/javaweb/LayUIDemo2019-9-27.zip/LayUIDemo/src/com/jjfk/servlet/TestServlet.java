package com.jjfk.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class TestServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String op = request.getParameter("op");
		
		request.setAttribute("userName", op);
		request.setAttribute("userName", op+"���»�");
		request.removeAttribute("userName");
		
		request.setAttribute("list", "list");
		
		//ģ���¼ ����
		if(("login").equals(op)){
			//�û���¼��Ϣ
			String uname = request.getParameter("uname");
			String upwd = request.getParameter("upwd");
			//ȥ���ݿ� �ȶ� �Ƿ� ���ڸö���
			//��������������
			
			//��ȡsession true: session �����ڲ����Զ�����
			HttpSession session = request.getSession(true);
			if(("admin").equals(uname)&&("123").equals(upwd)){
				
				//����session�У���ת���ɹ�ҳ��
				session.setAttribute("uname"+uname, uname);
				session.setAttribute("upwd", upwd);
				
				session.setMaxInactiveInterval(60*60);
				
				request.getRequestDispatcher("../index.jsp").forward(request, response);
			}
		}else if("exists".equals(op)){
			
			HttpSession session = request.getSession(false);
			
			session.invalidate();
			
			response.sendRedirect("../login.jsp");
		}
		
		//return "../index.jsp";
	}

}
