package com.jjfk.entity;

import javax.mail.search.DateTerm;

public class Tstudent {

	private int stu_no   ;
	private String stu_name ;
	private String stu_pwd ;
	private String stu_sex  ;
	private int stu_age  ;
	private String stu_birth;
	public int getStu_no() {
		return stu_no;
	}
	public void setStu_no(int stu_no) {
		this.stu_no = stu_no;
	}
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	public String getStu_pwd() {
		return stu_pwd;
	}
	public void setStu_pwd(String stu_pwd) {
		this.stu_pwd = stu_pwd;
	}
	public String getStu_sex() {
		return stu_sex;
	}
	public void setStu_sex(String stu_sex) {
		this.stu_sex = stu_sex;
	}
	public int getStu_age() {
		return stu_age;
	}
	public void setStu_age(int stu_age) {
		this.stu_age = stu_age;
	}
	public String getStu_birth() {
		return stu_birth;
	}
	public void setStu_birth(String stu_birth) {
		this.stu_birth = stu_birth;
	}
	public Tstudent(int stu_no, String stu_name, String stu_pwd, String stu_sex, int stu_age, String stu_birth) {
		super();
		this.stu_no = stu_no;
		this.stu_name = stu_name;
		this.stu_pwd = stu_pwd;
		this.stu_sex = stu_sex;
		this.stu_age = stu_age;
		this.stu_birth = stu_birth;
	}
	public Tstudent() {
		super();
	}

}
