package com.getwebsiteinfo.testTemp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.getwebsiteinfo.dao.impl.WebsitesImpl;
import com.getwebsiteinfo.entity.Websites;





public class TestTemp {

	public static void main(String[] args) {
		WebsitesImpl dao = new WebsitesImpl();
		
		//��ѯ����
//		ArrayList<Websites> list = dao.queryWebsites("sadf ");
//		if (list.size()==0) {
//			System.out.println("��");
//		}else {
//			for (Websites websites : list) {
//				System.out.println(websites.toString());
//			}
//		}
		
//		//�����ֲ�ѯ
//		System.out.println("######");
//		Websites w = dao.queryWebsite("΢��");
//		if (w.getName()==null) {
//			System.out.println("��!");
//		}else {
//			
//				System.out.println(w.toString());
//			
//		}	
		
//		//�����ֲ�ѯ
		System.out.println("######");
		Websites w = dao.queryWebsite("΢��");
		if (w.getName()==null) {
			System.out.println("��!");
		}else {
			
				System.out.println(w.toString());
			
		}
		
		//����
//		System.out.println("######");
//		Websites w2 = new Websites("�ٶ�", "www.baidu.com", "7", "CN");
//		boolean flag = dao.save(w2);
//		System.out.println(flag);
		//�޸�
//		System.out.println("######");
//		Websites w3 = new Websites(28,"��˳VCC", "www.baisadduasd.com", "16", "CN");
//		dao.Update(w3);

//		//��������ѯ
//		System.out.println("######");
//		ArrayList<Websites> w = dao.queryWebsites("CN");
//		for (Iterator iterator = w.iterator(); iterator.hasNext();) {
//			Websites websites = (Websites) iterator.next();
//			System.out.println(websites.toString());
//		}
		
		//��idɾ��
//		boolean flag = dao.delete(11);
//		System.out.println(flag);
	}
}
