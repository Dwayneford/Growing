package com.login.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.dao.Dao;
import com.login.entity.User;

//����ǰ�˴������Ϣ
public class RegisterServlet extends HttpServlet {

	/**
		 * Constructor of the object.
		 */
	public RegisterServlet() {
		super();
	}

	/**
		 * Destruction of the servlet. <br>
		 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}


	//����ǰ̨������ֵ�����˺ź�����
	//ע��ɹ���ҳ������ֱ��¼ҳ��
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String userpsw = request.getParameter("userpsw");
		
		
		User user = new User(username, userpsw);
		Dao dao = new Dao();
		if (dao.register(user)) {
			System.out.println("ע��ɹ�");
			
			response.sendRedirect("../userlogin.jsp");
		}else {
			System.out.println("ע��ʧ��");
			response.sendRedirect("../error.jsp");
		}
		
		
		
	}

	
	public void init() throws ServletException {
		// Put your code here
	}

}
