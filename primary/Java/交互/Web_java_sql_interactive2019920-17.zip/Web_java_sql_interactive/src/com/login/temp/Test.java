package com.login.temp;

import com.login.dao.Dao;
import com.login.entity.User;

public class Test {

	public static void main(String[] args) {
		//ע�����
//		User user = new User("test3", "123456");
//		Dao dao = new Dao();
//		System.out.println(dao.register(user));
		//��¼����
		User user = new User("zhangsan", "123456");
		Dao dao = new Dao();
		System.out.println((dao.login(user)).toString());
		
	}
	
}
