package com.login.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.login.dao.Dao;
import com.login.entity.User;

public class LoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String op =request.getParameter("method");
		if(("login").equals(op)){
			
			String name = request.getParameter("login_name");
			String psw = request.getParameter("password");
			User user = new User(name, psw);
			Dao dao = new Dao();
			if (dao.login(user) !=null) {
				System.out.println("��¼�ɹ�");
				//����session����
				HttpSession session = request.getSession();
				//����û���Ϣ
				session.setAttribute("name", name);
				session.setAttribute("pwd", psw);
				
				//�ж��û��Ƿ� ��ѡ������ yes
				String islogin=request.getParameter("islogin");
				if(("yes").equals(islogin)){
					//��ס���� ���� cookie,��ȡ cookie���󣬽����� ��Ӧ���ͻ���
					Cookie loginNmae = new Cookie("username", name);
					Cookie loginPwd = new Cookie("password", psw);
					//״̬
					Cookie loginType = new Cookie("islogin", islogin);
					
					//���� ��Чʱ��
					loginNmae.setMaxAge(60*60*24*12);
					loginPwd.setMaxAge(60*60*24*12);
					loginType.setMaxAge(60*60*24*12);
					
					//���������� ͨ����׺���� ȷ����Щ�ͻ��˿��� ��ȡcookieֵ
					loginNmae.setPath("/");//JavaWeb_02
					loginPwd.setPath("/");
					loginType.setPath("/");
					//������ ����
					loginNmae.setDomain("localhost");
					loginPwd.setDomain("localhost");
					loginType.setDomain("localhost");
					
					//��Ӧ�� �ͻ���
					response.addCookie(loginNmae);
					response.addCookie(loginPwd);
					response.addCookie(loginType);
					
				}else{
					//����ס���� ��� cookie, ��ȡ �ͻ���cookie
					Cookie[] cookies = request.getCookies();
					
					if(cookies!=null && cookies.length>0){
						//��ʼ ����
						for (int i=0;i<cookies.length;i++) {
							if(("username").equals(cookies[i].getName())){
								cookies[i].setMaxAge(0);
								cookies[i].setPath("/");
								//��Ӧ���ͻ���
								response.addCookie(cookies[i]);
							}
							if(("password").equals(cookies[i].getName())){
								cookies[i].setMaxAge(0);
								cookies[i].setPath("/");
								//��Ӧ���ͻ���
								response.addCookie(cookies[i]);					
							}
							if(("islogin").equals(cookies[i].getName())){
								cookies[i].setMaxAge(0);
								cookies[i].setPath("/");
								//��Ӧ���ͻ���
								response.addCookie(cookies[i]);
							}
						}
					}
				}
				//ҳ����ת				
				response.sendRedirect("http://localhost:8080/Web_java_sql_interactive/admin/index/index.html");
				
			}else {
				System.out.println("��¼����");
				response.sendRedirect("../error.jsp");
			}
			
		}else if(("exit").equals(op)){			
		}
		
	}

	public LoginServlet() {
		super();
	}


	public void destroy() {
		super.destroy();

	}
	
	public void init() throws ServletException {

	}

}
