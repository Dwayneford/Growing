package com.login.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.login.entity.User;
import com.login.util.JDBCUtil;
//���ݿ���صĴ���
public class Dao {
	
	public List<User> queryUser() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<User> list = new ArrayList<User>();
		String sql = "select * from useraccount";
		
		//�������ݿ⣬��ѯ����
				//����һ��JDBCUtil��Ķ���,��ʹ�������ӷ���
				conn = new JDBCUtil().getConn();
				//�ô����Ӷ���ķ�����sql���Ԥ����,�õ�һ��Ԥ�������
				try {
					ps = conn.prepareStatement(sql);
				} catch (SQLException e) {
					System.out.println("Ԥ����sql���ʧ�ܣ�");
					e.printStackTrace();
				}
				//Ԥ������ɺ�ִ��sql���,�õ������
				try {
					rs = ps.executeQuery();
				} catch (SQLException e) {
					System.out.println("��ѯʧ��!");
					e.printStackTrace();
				}
				//��������װ�����
				try {
					while (rs.next()) {
						User user = new User(rs.getString("name"),
											 rs.getString("psw"));

						list.add(user);
					}
				} catch (SQLException e) {
					System.out.println("��������װ���������");
					e.printStackTrace();
				}
				
				return list;
	}
	
	//��¼����
	public User login( User user){
		User resultUser = null ;
		Connection conn = null ;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		conn = new JDBCUtil().getConn();
		String sql = "select * from useraccount where name=? and psw=?";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, user.getName());
			psmt.setString(2, user.getPsw());
			rs = psmt.executeQuery();
			if (rs.next()) {
				resultUser = new User();
				resultUser.setName(rs.getString("name"));
				resultUser.setPsw(rs.getString("psw"));
				System.out.println("��¼�ɹ�");
			}			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		return resultUser;		
	}
	
	//ע�Ṧ��
	public boolean register( User user){
		Boolean flag = false ; 
		Connection conn =null;
		PreparedStatement pstmt = null;
		String sql = "insert into useraccount(name,psw) values(?,?)";
		try {
			conn = new JDBCUtil().getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getName());
			pstmt.setString(2, user.getPsw());
			int rowNum = pstmt.executeUpdate();
			if (rowNum>0) {
				flag = true;
				System.out.println("ע��ɹ�");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}				
		return flag;
		
	}
	//��ѯ����
//		public User query(){
//			User resultUser = null ;
//			Connection conn = null ;
//			PreparedStatement psmt = null;
//			ResultSet rs = null;
//			conn = new JDBCUtil().getConn();
//			String sql = "select * from useraccount";
//			try {
//				psmt = conn.prepareStatement(sql);
//				rs = psmt.executeQuery();
//				if (rs.next()) {
//					resultUser = new User();
//					resultUser.setName(rs.getString("name"));
//					resultUser.setPsw(rs.getString("psw"));
//				}			
//			} catch (SQLException e) {			
//				e.printStackTrace();
//			}
//			return resultUser;		
//		}
	

	
	
}

