package com.getwebsiteinfo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.getwebsiteinfo.dao.IWebsites;
import com.getwebsiteinfo.dao.impl.WebsitesImpl;
import com.getwebsiteinfo.entity.Websites;
import com.google.gson.Gson;

public class crossdomainservlet extends HttpServlet {


	public crossdomainservlet() {
		super();
	}


	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		//�����ʽ����
				request.setCharacterEncoding("utf-8");
				response.setCharacterEncoding("utf-8");
				//ͨ�������ж�ִ�кη���
				String op = request.getParameter("op");
				if (("queryWebsitesList").equals(op)) {
					//�����б���ѯ����
					queryWebsitesList(request, response);
				}
				
				
	}

	public void queryWebsitesList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		//����dao�㷽����ȡ�б�����
		IWebsites iWebsites = new WebsitesImpl();
		//���ص�����
		List<Websites> retList = iWebsites.queryWebsites();
		
		String callback = request.getParameter("callback"); //jsonp��Ӧ��ֵ
		
		//ƴ�ӳ� layUI��Ҫ�ĸ�ʽ����
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("code", 0);
		map.put("msg", "");
		map.put("count", 200);
		map.put("data", retList);
		
		//�����ݷ��ص�ҳ���ϣ�ת��Ϊjson��ʽ����gson fastjson
		//[{},{},{}]
				Gson gs =new Gson();
				String jsonWebsites = gs.toJson(map);
//				String jsonWebsites = gs.toJson(retList);
				System.out.println("wsEnt===>"+jsonWebsites);
				//��ͻ������
				PrintWriter out = response.getWriter();
				
				
				
				out.print(jsonWebsites);
				//ˢ�¹ر�
				out.flush();
				out.close();
		
	}


	public void init() throws ServletException {

	}

}
