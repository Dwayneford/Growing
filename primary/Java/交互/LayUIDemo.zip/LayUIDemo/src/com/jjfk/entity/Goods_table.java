package com.jjfk.entity;

public class Goods_table {
	private int good_id;
	private String good_name;
	private int good_num;
	private String good_type;
	private double good_price;
	private String good_date;
	private String good_beg_time;
	public int getGood_id() {
		return good_id;
	}
	public void setGood_id(int good_id) {
		this.good_id = good_id;
	}
	public String getGood_name() {
		return good_name;
	}
	public void setGood_name(String good_name) {
		this.good_name = good_name;
	}
	public int getGood_num() {
		return good_num;
	}
	public void setGood_num(int good_num) {
		this.good_num = good_num;
	}
	public String getGood_type() {
		return good_type;
	}
	public void setGood_type(String good_type) {
		this.good_type = good_type;
	}
	public double getGood_price() {
		return good_price;
	}
	public void setGood_price(double good_price) {
		this.good_price = good_price;
	}
	public String getGood_date() {
		return good_date;
	}
	public void setGood_date(String good_date) {
		this.good_date = good_date;
	}
	public String getGood_beg_time() {
		return good_beg_time;
	}
	public void setGood_beg_time(String good_beg_time) {
		this.good_beg_time = good_beg_time;
	}
	public Goods_table(int good_id, String good_name, int good_num, String good_type, double good_price,
			String good_date, String good_beg_time) {
		super();
		this.good_id = good_id;
		this.good_name = good_name;
		this.good_num = good_num;
		this.good_type = good_type;
		this.good_price = good_price;
		this.good_date = good_date;
		this.good_beg_time = good_beg_time;
	}
	public Goods_table() {
		super();
	}
	@Override
	public String toString() {
		return "Goods_table [good_id=" + good_id + ", good_name=" + good_name + ", good_num=" + good_num
				+ ", good_type=" + good_type + ", good_price=" + good_price + ", good_date=" + good_date
				+ ", good_beg_time=" + good_beg_time + "]";
	}
}
