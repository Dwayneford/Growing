package com.jjfk.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.jjfk.dao.IGoods;
import com.jjfk.dao.impl.GoodsImpl;
import com.jjfk.entity.Goods_table;
import com.jjfk.util.PageModel;

public class LayUIServler extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//������Ӧ���ı����ݸ�ʽ
		response.setContentType("text/html");
		//���ñ����ʽ
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		
		//���ղ��� �ж�ִ���Ǹ�����
		String op = request.getParameter("method");//��������Ĳ���
		if(("queryPage").equals(op)){
			//���� ��ҳ��ѯ ����
			queryPage(request, response);
		}else if(("myPage").equals(op)){
			myPgaeInfo(request, response);
		}else if(("queryById").equals(op)){
			queryById(request, response);
		}else if(("updateGoods").equals(op)){
			updateGoods(request, response);
		}
		
		//ҵ���߼� д�ڸ÷�����.....
		
	}
	/**
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void updateGoods(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		//��ȡ����
		String good_id = request.getParameter("good_id");
		String good_name = request.getParameter("good_name");
		String good_num = request.getParameter("good_num");
		String good_type = request.getParameter("good_type");
		String good_price = request.getParameter("good_price");
		String good_date = request.getParameter("good_date");
		String good_beg_time = request.getParameter("good_beg_time");
		//���÷���
		IGoods goodao = new GoodsImpl();
		//��װ����
		Goods_table gdEnt = new Goods_table(Integer.parseInt(good_id), 
								good_name, 
								Integer.parseInt(good_num), 
								good_type, 
								Double.parseDouble(good_price), 
								good_date, 
								good_beg_time);
		boolean bool = goodao.saveOrUpdate(gdEnt);
		//����ı���Ϣ
		PrintWriter out = response.getWriter();
		if (bool) {
			out.print("�����ɹ�����");
		}else{
			out.print("����ʧ�ܣ���");
		}
	}
	
	/**
	 * ͨ��ID�鿴����
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void queryById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		IGoods goodao = new GoodsImpl();
		//��ȡ
		String goodId = request.getParameter("goodId");
		Goods_table gdEnt =null;
		//�ж� ת��
		if(goodId!=null && !("").equals(goodId)){
			 gdEnt = goodao.getGoodsInfo(Integer.parseInt(goodId));
		}
		//����������
		request.setAttribute("gdEnt", gdEnt);
		//��Ӧ��ҳ��
 		//request.getRequestDispatcher("../showGoodInfo.jsp").forward(request, response);
		request.getRequestDispatcher("../editGoodInfo.jsp").forward(request, response);
	}
	
	/**
	 * ��ҳ��ѯ �б����� ��Ʒ��Ϣ
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void queryPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡ ��ҳ����
		String pageNum = request.getParameter("page");
		String limitNum = request.getParameter("limit");
		System.out.println(pageNum+"=="+limitNum);
		
		//���� javaBean ��ȡ���ݿ��е����� ��model+Dao+....=javaBean��
		IGoods goodDao = new GoodsImpl();
		//���÷���
		//List<Goods_table> list = goodDao.queryGoods(null, 0.00);
		Map< String, Object> map = new HashMap<String, Object>();
		map.put("page", Integer.parseInt(pageNum));
		map.put("limit", Integer.parseInt(limitNum));
		
		int countRow = goodDao.countRow(map);
		ArrayList<Goods_table> list = goodDao.layPage(map);
		
		//ƴ�ӳ� layUI��Ҫ�ĸ�ʽ����
		Map<String, Object> retMap = new HashMap<String, Object>();
		retMap.put("code", 0);
		retMap.put("msg", "success");
		retMap.put("count", countRow);
		retMap.put("data", list);
		
		//�� map�������� ת��Ϊ json��ʽ ��Ӧ�� �ͻ���
		Gson g = new Gson();
		String jsonStr = g.toJson(retMap);
		
		//��Ӧ
		PrintWriter out = response.getWriter();
		out.print(jsonStr);
	}
	/**
	 * �Զ��� ������ѯ
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void myPgaeInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IGoods gdao = new GoodsImpl();
		//��ҳ����
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("size", request.getParameter("size"));
		map.put("currentPage", request.getParameter("currentPage"));
		
		PageModel<Goods_table> pm = gdao.queryPage(map);
		
		request.setAttribute("pm", pm);
		//��Ӧ��ҳ����
		request.getRequestDispatcher("../goodPage.jsp").forward(request, response);
	}
	
}
