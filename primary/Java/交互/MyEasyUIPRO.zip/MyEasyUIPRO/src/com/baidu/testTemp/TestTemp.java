package com.baidu.testTemp;

import java.util.ArrayList;
import java.util.List;

import com.baidu.dao.impl.WebsitesImpl;
import com.baidu.entity.Websites;



public class TestTemp {

	public static void main(String[] args) {
		WebsitesImpl dao = new WebsitesImpl();
		List<Websites> list = dao.queryGoods("country");
		if (list.size()==0) {
			System.out.println("��!");
		}else {
			for (Websites m : list) {
				System.out.println(m.toString());
			}
		}			
		
		
	}
}
