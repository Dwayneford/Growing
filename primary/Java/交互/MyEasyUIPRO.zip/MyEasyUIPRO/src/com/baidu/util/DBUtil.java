package com.baidu.util;


import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.servlet.jsp.tagext.TryCatchFinally;



public class DBUtil {
	
	static String className;
	static String url;
	static String user;
	static String password;
	
	{
		//��ȡproperties�ļ���ֵ
		ResourceBundle rb = ResourceBundle.getBundle("jdbc");
		//��ȡ��Ӧ�ļ�ֵ
//		className = rb.getString(className);
		url = rb.getString("url");
		user = rb.getString("user");
		password = rb.getString("password");
		
	}
	//��֤�����Ƿ����
	static{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	//���ݿ����ӷ���
	public Connection getCon(){
		Connection conn = null;
		//�������
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return conn;
	};
	
	//���ݿ�رշ���
	public void closeDB(ResultSet rs, PreparedStatement ps,Connection conn){
		
			try {
				if(rs!=null)rs.close();
				if(ps!=null)ps.close();
				if(conn!=null)conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	
	
	
	
	
	
	
	
//	public static void main(String[] args) {
//		DBUtil db =new DBUtil();
//		Connection conn = db.getConn();
//		System.out.println("===>"+conn);
//		
//
//		
//	}
//	
//	//�������ݿ���Ҫ�Ĳ���
//	public static String url="jdbc:mysql://127.0.0.1:3306/easyuipro?userUnicode=true&characterEncoding=utf-8&serverTimezone=UTC";
//	public static String user="root";
//	public static String password="root";
//	
//	//��������Ƿ��������
//	static{
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//	}
//	//���ݿ����ӷ���
//	public 	Connection getConn(){
//		Connection conn= null;
//		try {
//			conn=DriverManager.getConnection(url,user,password);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}		
//		return conn;		
//	}
//	
//	//���ݿ�رշ���
//	public void closeDB(ResultSet rs , PreparedStatement ps , Connection conn){
//		
//			try {
//				if(rs!= null)rs.close();
//				if(ps != null)ps.close();
//				if(conn != null)conn.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//	}	
		
}










