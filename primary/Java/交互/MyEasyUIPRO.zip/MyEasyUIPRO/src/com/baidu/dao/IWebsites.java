package com.baidu.dao;

import java.util.List;

import com.baidu.entity.Websites;

public interface IWebsites {
	
	public List<Websites> queryGoods(String country);
}
