package JAVA框架.hibernate;

import java.util.Iterator;
import java.util.List;

import org.jboss.jandex.Main;

import com.yc123.dao.impl.JingdianIMPL;
import com.yc123.model.JingdianTable;

public class Test {

	public static void main(String[] args) {
		//添加测试
		JingdianIMPL jd =new JingdianIMPL();
//		boolean bool = jd.AddJingdian(null);
//		System.out.println("添加"+bool);
		
		//删除测试
//		new JingdianTable(23, "张家界", "湖北", "张家界天境")
		//删除的对象必须设置ID		
//		JingdianTable jd2 = new JingdianTable();
//		jd2.setJingdianId(1);
//		boolean bool = jd.DeleteJingdian(jd2);
//		System.out.println("删除"+bool);
		
		//修改方法测试
		
//		JingdianTable jd3 = new JingdianTable(999, "名称修改", "底子修改", "描述修改");
//		jd3.setJingdianId(5);
//		
//		boolean bool = jd.updateJingdian(jd3);
//		System.out.println("修改"+bool);
		
		
		
//		List list = jd.queryJingdian();
//		for (Object object : list) {
//			JingdianTable jd2 = (JingdianTable) object;
//			System.out.println(object.toString());
//		}
		
		//分页查询测试
		
		List list = jd.queryPage(3, 1);
		for (Object object : list) {
			JingdianTable jd2 = (JingdianTable) object;
			System.out.println(object.toString());
		}
		
		
		
	}
	
	
	
	
	
}
