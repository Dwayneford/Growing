package JAVA框架.hibernate;

public class _02_hibernate框架 {

}
/*


1、在database explorer内新建一个数据库连接；
2、configure facets 内构建hibernate环境；
3、数据库连接里选择待导出的表，用hibernate reverse engineering 将其转化为实体类
















*/