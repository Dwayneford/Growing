package JAVA框架.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BaseDao {

	//创建工程	
	private static SessionFactory factory ;
	//初始化，获取hibernate配置
	static {
		Configuration cfg = new Configuration().configure();
		//获取工厂对象
		factory = cfg.buildSessionFactory();
		
	}
	
	public boolean commAdd (Object obj){
		//创建session
		Session session = factory.openSession();
		//开启事务
		Transaction ts = session.beginTransaction();
		
		try {
			session.save(obj);
			ts.commit();
			return true ;
		} catch (Exception e) {
			ts.rollback();
		}finally {
			session.close();
		}
		return false;
		
	}
	
	
	public boolean commDelete (Object obj){
		//创建session
		Session session = factory.openSession();
		//开启事务
		Transaction ts = session.beginTransaction();
		
		try {
			session.delete(obj);
			ts.commit();
			return true ;
		} catch (Exception e) {
			ts.rollback();
		}finally {
			session.close();
		}
		return false;
		
	}
	
	public boolean commUpdate (Object obj){
		//创建session
		Session session = factory.openSession();
		//开启事务
		Transaction ts = session.beginTransaction();
		
		try {
			session.update(obj);;
			ts.commit();
			return true ;
		} catch (Exception e) {
			ts.rollback();
		}finally {
			session.close();
		}
		return false;
		
	}
	
	public List commQuery (String hql , Object ...obj ){
		//创建session
		Session session = factory.openSession();

		Query query = session.createQuery(hql);
		
		//判断是否有参数赋值
		if (obj.length > 0) {
			for (int i = 0; i < obj.length; i++) {
				query.setParameter(i, obj[i]);
			}
		}
		session.close();

		return query.list();		
	}
	
	//get()   load()
	public Object getObj(Class csl , int id ){
		Session session = factory.openSession();
		Object obj = session.get(csl, id);
		
		session.close();
		return obj ;
		
	}
	
	/**
	 * 分页查询
	 */
	
	public List commonQueryPage(String hql , int pageSize ,int pageNo , Object ...parms){
		//创建session
		Session session = factory.openSession();
		Query query = session.createQuery(hql);
		
		//赋值
		//设置分页参数
		query.setFirstResult((pageNo-1)*pageSize);
		query.setMaxResults(pageSize);
		
		List list = query.list();
		session.close();
		return list ;
		
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
}
