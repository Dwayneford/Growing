package JAVA框架.hibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

import com.yc123.model.DindanTable;
import com.yc123.model.JingdianTable;
import com.yc123.model.XianluTable;
import com.yc123.util.BaseDao;

public class JingdianIMPL extends BaseDao{

	public boolean AddJingdian(JingdianTable jd){
		BaseDao bd = new BaseDao();
//		JingdianTable jingdian = new JingdianTable(tupianId, mingcheng, dizhi, miaosu, xianluTables)
//		XianluTable xl = new XianluTabl
		JingdianTable jingdian = new JingdianTable(23, "张家界", "湖北", "张家界天境");
		
		boolean bool = bd.commAdd(jingdian);
		
		return bool;
		
	}
	
	public boolean DeleteJingdian(JingdianTable jd){
		BaseDao bd = new BaseDao();
		boolean bool = bd.commDelete(jd);
		
		return bool;

	}
	
	//修改方法
	public boolean updateJingdian(JingdianTable jd){
		BaseDao bd = new BaseDao();
		boolean bool = bd.commUpdate(jd);
		
		return bool;
	}
	
	
	//普通查询方法
	public List queryJingdian(){
		BaseDao bd = new BaseDao();
		String hql = "from JingdianTable where mingcheng = ?";
		List<DindanTable> list = bd.commQuery(hql, "电风扇");
		
		return list;
	}
	//分页查询
	public List queryPage(int pageSize ,int pageNo ){
		BaseDao bd = new BaseDao();
		String hql = "from JingdianTable ";
//		bd.commonQueryPage(hql, pageSize, pageNo, parms)
		List list = bd.commonQueryPage(hql, pageSize, pageNo, "");
		return list ;
	}
	
	
	@Test
	public void test1(){
		
//		Configuration configuration = new Configuration();
//		Configuration cfg = configuration.configure();
		
		Configuration cfg = new Configuration().configure();
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		JingdianTable jd1 = session.load(JingdianTable.class, 2);
		System.out.println(jd1);
		
		//关闭session再打开，关闭的同时删除了缓存，所以需要发送两次查询语句
		//未关闭只需发送一次（第二次从缓存中读取）
		session.close();
		Session session2 = sessionFactory.openSession();
		
		JingdianTable jd2 = session2.load(JingdianTable.class, 2);
		System.out.println(jd2);
		
		
	}
	
	
	
	
	
	
}
