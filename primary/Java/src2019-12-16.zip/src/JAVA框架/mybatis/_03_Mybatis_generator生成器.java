package JAVA框架.mybatis;





public class _03_Mybatis_generator生成器 {

}
/*

mybatis-generator生成dao实体，mapper:
1、两个包
mybatis-generator-core-1.3.2.jar
mysql-connector-java-5.1.25-bin.jar
2、配置文件
generatorConfig.xml：

3、运行生成函数

*/


/*

public static void main(String[] args) throws Exception {
	    List<String> warnings = new ArrayList<String>();
	    boolean overwrite = true;
	    //指向逆向工程配置文件
	    File configFile = new File("generatorConfig.xml"); 
	    ConfigurationParser cp = new ConfigurationParser(warnings);
	    Configuration config = cp.parseConfiguration(configFile);
	    DefaultShellCallback callback = new DefaultShellCallback(overwrite);
	    MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config,
	            callback, warnings);
	    myBatisGenerator.generate(null);
	    
	    for (String string : warnings) {
			System.out.println(string);
		}
	    System.out.println("结束");
	}


 */



/*
<?xml version="1.0" encoding="UTF-8" ?>

    <!DOCTYPE generatorConfiguration 
      PUBLIC "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN"
      "http://mybatis.org/dtd/mybatis-generator-config_1_0.dtd">

<generatorConfiguration>
   <!--  C:\Users\Administrator\.m2\repository\mysql\mysql-connector-java\5.1.6 -->
    <classPathEntry
        location="C:/Users/Administrator/.m2/repository/mysql/mysql-connector-java/5.1.6/mysql-connector-java-5.1.6.jar" />
    <context id="mysqlTables" targetRuntime="MyBatis3">
    
        <commentGenerator>
            <property name="suppressAllComments" value="true" />
        </commentGenerator>
        
        <jdbcConnection driverClass="com.mysql.jdbc.Driver"
            connectionURL="jdbc:mysql://localhost:3306/haozuke?userUnicode=true&amp;characterEncoding=utf-8&amp;serverTimezone=GMT%2B8"
            userId="root" password="root">
        </jdbcConnection>
        
        <javaTypeResolver>
            <property name="forceBigDecimals" value="false" />
        </javaTypeResolver>

         <!-- 生成model模型，对应的包，存放位置可以指定具体的路径,如/ProjectName/src，也可以使用MAVEN来自动生成 -->
        <javaModelGenerator targetPackage="src/main/java/entity"
            targetProject="D:\MyEclipse 2017 CI\workspace\SS2M\src">
            <property name="enableSubPackages" value="true" />
            <property name="trimStrings" value="true" />
        </javaModelGenerator>
        
         <!--对应的xml mapper文件  -->
        <sqlMapGenerator targetPackage="src/main/java/mappers" targetProject="D:\MyEclipse 2017 CI\workspace\SS2M\src">
            <property name="enableSubPackages" value="true" />
        </sqlMapGenerator>
        
        <!-- 对应的dao接口 -->
        <javaClientGenerator type="XMLMAPPER"
            targetPackage="src/main/java/dao" targetProject="D:\MyEclipse 2017 CI\workspace\SS2M\src">
            <property name="enableSubPackages" value="true" />
        </javaClientGenerator>

         <!-- 这里是数据库的表名table_user 以及 POJO类的名字User -->
        <table tableName="user_house_table" domainObjectName="look_id"
            enableCountByExample="false" enableSelectByExample="false"
            enableUpdateByExample="false" enableDeleteByExample="false">

        </table>
        <table tableName="user_house_table" domainObjectName="display"
            enableCountByExample="false" enableSelectByExample="false"
            enableUpdateByExample="false" enableDeleteByExample="false">

        </table>
        <table tableName="user_house_table" domainObjectName="house_states_id"
            enableCountByExample="false" enableSelectByExample="false"
            enableUpdateByExample="false" enableDeleteByExample="false">
        </table>
        <table tableName="user_house_table" domainObjectName="user_id"
            enableCountByExample="false" enableSelectByExample="false"
            enableUpdateByExample="false" enableDeleteByExample="false">
        </table>
    </context>

</generatorConfiguration>

*/