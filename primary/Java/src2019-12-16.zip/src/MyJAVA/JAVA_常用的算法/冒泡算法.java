package MyJAVA.JAVA_常用的算法;

import java.util.Arrays;

public class 冒泡算法 {

	public static void main(String[] args) {
		int[] arr = { 9,8,7,6,5,4,3,2,1,0 };
		int[] arr2 = { 9,8,7,6,5,4,3,2,1,0};
		System.out.println("排序前"+Arrays.toString(arr));
		bubbleSort(arr);
		System.out.println("排序后"+Arrays.toString(arr));
		
		bubbleSortImprove(arr2);
		System.out.println("优化排序后"+Arrays.toString(arr2));
	}
	
	
	public static void bubbleSort(int[] arr){
		int temp ;
		

//		int[] arr = { 9,8,7,6,,54,3,2,1};
		//第一次循环
//		int[] arr = { 9,8,7,6,5,4,3,2,1};
//		int[] arr = { 8,7,7,6,,5,4,3,2,1};
		for (int i = 0; i < arr.length-1; i++) {
			for (int j = 0; j < arr.length-1-i; j++) {
				
				//两个数比较，选出大的一个，和面的比，可以锁定大的一个，将最大的放到最后面
				//外循环控制内循环做i次，能将i个元素全部排序
				if (arr[j]>arr[j+1]) {
					//temp为大
					temp = arr[j];
					arr[j] = arr[j+1];
					//后一个元素变为大，大的一个被锁定
					arr[j+1]=temp;
				}
			}
		}
		
	}
	
	
	//优化冒泡舒算法			连续无序数组：	若arr[j] - arr[j+1] = 1
	 public static void bubbleSortImprove(int[] values) {
	        int temp;
	        int i;
	        // 外层循环：n个元素排序，则至多需要n-1趟循环
	        for (i = 0; i < values.length - 1; i++) {
	            // 定义一个布尔类型的变量，标记数组是否已达到有序状态
	            boolean flag = true;
	    /*内层循环：每一趟循环都从数列的前两个元素开始进行比较，比较到无序数组的最后*/
	            for (int j = 0; j < values.length - 1 - i; j++) {
	                // 如果前一个元素大于后一个元素，则交换两元素的值；
	                if (values[j] > values[j + 1]) {
	                    temp = values[j];
	                    values[j] = values[j + 1];
	                    values[j + 1] = temp;
	                       //本趟发生了交换，表明该数组在本趟处于无序状态，需要继续比较；
	                    flag = false;
	                }
	            }
	           //根据标记量的值判断数组是否有序，如果有序，则退出；无序，则继续循环。
	            if (flag) {
	                break;
	            }
	        }
	    }
	
	
}
