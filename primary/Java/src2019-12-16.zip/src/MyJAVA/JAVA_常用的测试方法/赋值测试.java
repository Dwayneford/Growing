package MyJAVA.JAVA_常用的测试方法;

public class 赋值测试 {

	public void method(String str){
		str="12345";
		System.out.println("方法内部"+str);
	}
	public static void main(String[] args) {
		赋值测试 fzcs = new 赋值测试();
		String str = "hello world ";
		fzcs.method(str);
		System.out.println(str);
	}
	
}
