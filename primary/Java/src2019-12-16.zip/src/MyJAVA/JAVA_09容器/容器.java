
package MyJAVA.JAVA_09容器;

import java.util.ArrayList;

public class 容器 {

	public static void main(String[] args) {
		ArrayList arr = new ArrayList();
	}
}

/*

  (1) 数组：占用空间连续。 寻址容易，查询速度快。但是，增加和删除效率非常低。

  (2) 链表：占用空间不连续。 寻址困难，查询速度慢。但是，增加和删除效率非常高。

泛型的本质就是“数据类型的参数化”。

list
	有序
	可重复
	
	ArrayList
	linkedlist
	vector

	ArrayList底层是用数组实现的存储。 特点：查询效率高，增删效率低，线程不安全。
	
	LinkedList底层用双向链表实现的存储。特点：查询效率低，增删效率高，线程不安全。entry
	
	Vector底层是用数组实现的List，相关的方法都加了同步检查，因此“线程安全,效率低”。


Map就是用来存储“键(key)-值(value) 对”的。
	Map 接口的实现类有HashMap、TreeMap、HashTable、Properties等。

	  1. HashMap: 线程不安全，效率高。允许key或value为null。

      2. HashTable: 线程安全，效率低。不允许key或value为null。


”key-value两个对象”成对  '存放' 到HashMap的Entry[]数组中。参见以下步骤：

  (1)首先调用key对象的hashcode()方法，获得hashcode。

  (2)根据hashcode计算出hash值(要求在[0, 数组长度-1]区间) , hash值 = hashcode&(数组长度-1)。
		
  (3) 生成Entry对象  , key对象、value对象、hash值、指向下一个Entry对象的引用(null)。
	
  (4) 将Entry对象放到table数组中


取数据过程get(key)

  (1) 获得key的hashcode，通过hash()散列算法得到hash值，进而定位到数组的位置。

  (2) 在链表上挨个比较key对象。 调用equals()方法，和链表上所有节点的key对象进行比较，直到碰到返回true的节点对象为止。

  (3) 返回equals()为true的节点对象的value对象。




Set容器特点：无序、不可重复。

	Set常用的实现类有：HashSet、TreeSet

	往set中加入元素，本质就是把这个元素作为key加入到了内部的map中

Collections工具类

      类 java.util.Collections 提供了对Set、List、Map进行排序、填充、查找元素的辅助方法。

      1. void sort(List) //对List容器内的元素排序，排序的规则是按照升序进行排序。

      2. void shuffle(List) //对List容器内的元素进行随机排列。

      3. void reverse(List) //对List容器内的元素进行逆续排列 。

      4. void fill(List, Object) //用一个特定的对象重写整个List容器。

      5. int binarySearch(List, Object)//对于顺序的List容器，采用折半查找的方法查找特定对象。




*/