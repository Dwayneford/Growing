package MyJAVA.设计模式.单例模式.饿汉模式;
//饿汉模式，构造函数私有化，无法new，只能通过方法获取对象，从而一个类最多只有一个实例
//饿汉模式类加载的时候就实例化了对象，而懒汉模式是调用getInstance方法时才实例化对象
public class Singleton {

	private static Singleton instance = new Singleton();
	private Singleton(){};
	public static Singleton getinstance(){
		return instance;
	}
	
	public void say(){
		System.out.println("hello world !");
	}
}
