package MyJAVA.设计模式.单例模式.懒汉模式;

public class 懒汉 {

	private static 懒汉 instance ;
	private 懒汉(){};
	public static /* synchronized */ 懒汉 getinstace(){
		if (instance == null) {
			return new 懒汉();
		}
		return instance;
	}
}
