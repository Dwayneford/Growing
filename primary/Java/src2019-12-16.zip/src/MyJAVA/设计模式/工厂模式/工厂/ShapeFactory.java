package MyJAVA.设计模式.工厂模式.工厂;

import MyJAVA.设计模式.工厂模式.实现类.Circle;
import MyJAVA.设计模式.工厂模式.实现类.Rectangle;
import MyJAVA.设计模式.工厂模式.实现类.Square;
import MyJAVA.设计模式.工厂模式.接口.Shape;

public class ShapeFactory {

	public Shape getShape(String shapeType){
		if (shapeType ==null) {
			return null ;
		}else if (shapeType.equalsIgnoreCase("circle")) {
			return new Circle();
		}else if (shapeType.equalsIgnoreCase("rectangle")) {
			return new Rectangle();
		}else if (shapeType.equalsIgnoreCase("Square")) {
			return new Square();
		}
		return null;

	}
	
}
