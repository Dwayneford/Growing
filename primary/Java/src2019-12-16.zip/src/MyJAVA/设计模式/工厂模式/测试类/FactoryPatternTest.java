package MyJAVA.设计模式.工厂模式.测试类;

import MyJAVA.设计模式.工厂模式.工厂.ShapeFactory;
import MyJAVA.设计模式.工厂模式.接口.Shape;
/**
 * 	定义一个创建对象的接口，
 *  让其通过逻辑决定实例化哪一个工厂类，
 *  工厂模式使其创建过程延迟到子类进行。
 * @author Administrator
 *
 */
public class FactoryPatternTest {
	public static void main(String[] args) {
		ShapeFactory sf = new ShapeFactory();
		Shape  shape1 =sf.getShape("circle");
		shape1.draw();
		Shape  shape2 =sf.getShape("rectangle");
		shape2.draw();
		Shape  shape3 =sf.getShape("square");
		shape3.draw();
		
	}
}
