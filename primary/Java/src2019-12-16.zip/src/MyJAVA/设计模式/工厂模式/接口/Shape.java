package MyJAVA.设计模式.工厂模式.接口;

public interface Shape {
	void draw();
}
