package MyJAVA.JAVA_常用的方法;
/*
 *  instanceof是二元运算符，左边是对象，右边是类；
 *  当对象是右面类或子类所创建对象时，返回true；否则，返回false。
 * 
 * 
 */
public class TestInstanceOf {

	public static void main(String[] args) {
        Student stu = new Student("高淇",172,"Java");
        Person ps = new Person();
        System.out.println(ps instanceof Student);
        System.out.println(stu instanceof Person);
        System.out.println(stu instanceof Student);
    }
}
class Person {
	private String sexP ;
	String sex;
    String name;
    int height;
    public void rest(){
        System.out.println("休息一会！");
    }  
}
class Student extends Person {
    String major; //专业
    public void study(){
        System.out.println("在尚学堂，学习Java");
    }  
    public Student(String name,int height,String major) {
        //天然拥有父类的属性
        this.name = name;
        this.height = height;
        this.major = major;
        this.sex=sex;
    }
}