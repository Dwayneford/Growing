package MySql.基础;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

//数据库连接类
//JDBC:Java DataBase Connectivity
public class JDBCUtil {

//	static String className;	//com.mysql.jdbc.Driver,高版本为com.mysql.jc.jdbc.Driver
	static String url;			//url=jdbc:mysql://127.0.0.1/mysql2019815?userUnicode=ture%characterEncoding=utf-8&serverTimezone=GMT%2B8
	static String user;			//?userUnicode=ture%characterEncoding=utf-8&serverTimezone=GMT%2B8
	static String password;		
	
	{
		//获取properties文件的对象和值值
		//用drivermanager创建conn对象时会用到
		ResourceBundle rb = ResourceBundle.getBundle("JDBCFile");
		//获取键对应的值
		url = rb.getString("properties_url");
		user = rb.getString("properties_user");		
		password = rb.getString("properties_password");		
//		className = rb.getString("className");		
	}
	
	//检查驱动是否存在
	static{
		try {
			//需要将驱动复制一份放到Tomcat的lib中
			Class.forName("com.mysql.cj.jdbc.Driver");
//			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("驱动不存在！");
			e.printStackTrace();
		}
	}
	
	//数据库连接方法
	public Connection getConn(){
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			System.out.println("连接数据库时失败!");
			e.printStackTrace();
		}
		return conn;		
	}
	//数据库关闭方法
	public void closeDB(ResultSet rs , PreparedStatement ps , Connection conn){
		try {
			if (rs!=null)rs.close(); 	//关闭结果集
			if (ps!=null)ps.close();	//关闭预编译sql语句对象
			if (conn!=null)conn.close();	//关闭连接对象
		} catch (Exception e) {
			System.out.println("数据库关闭失败!");
		}
	}	
}
