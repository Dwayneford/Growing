package com.yc123.action;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.yc123.model.UserEnt;

public class UserInfoAction extends ActionSupport{
	private UserEnt userent;
	
	public UserEnt getUserent() {
		return userent;
	}

	public void setUserent(UserEnt userent) {
		this.userent = userent;
	}

	/**
	 * ��ȡ�û���Ϣ
	 * @return
	 *     ActionName-conversion.properties
	 * UserInfoAction-conversion.properties
	 */
	
	public String showInfo(){
		
		System.out.println("�û���ϢΪ��"+userent.toString());
		//����������
		ActionContext.getContext().put("userent", userent);
		return SUCCESS;
	}
	
}
