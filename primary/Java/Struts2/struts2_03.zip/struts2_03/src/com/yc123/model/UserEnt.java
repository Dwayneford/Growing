package com.yc123.model;

import java.util.Date;

public class UserEnt {
	private int userNo;
	private String userName;
	private String userPwd;
	private String userPower;
	private Date userBirthday;
	
	
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getUserPower() {
		return userPower;
	}
	public void setUserPower(String userPower) {
		this.userPower = userPower;
	}
	public Date getUserBirthday() {
		return userBirthday;
	}
	public void setUserBirthday(Date userBirthday) {
		this.userBirthday = userBirthday;
	}
	public UserEnt(int userNo, String userName, String userPwd, String userPower, Date userBirthday) {
		super();
		this.userNo = userNo;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userPower = userPower;
		this.userBirthday = userBirthday;
	}
	public UserEnt() {
		super();
	}
	@Override
	public String toString() {
		return "UserEnt [userNo=" + userNo + ", userName=" + userName + ", userPwd=" + userPwd + ", userPower="
				+ userPower + ", userBirthday=" + userBirthday + "]";
	}
	
}
