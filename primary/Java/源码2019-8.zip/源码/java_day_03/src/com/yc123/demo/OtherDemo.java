package com.yc123.demo;

public class OtherDemo {
	public static void main(String[] args) {
		
		Modifier modEnt = new Modifier();
		
		modEnt.hello1();
		modEnt.hello2();
		modEnt.hello3();
		
	}
}
