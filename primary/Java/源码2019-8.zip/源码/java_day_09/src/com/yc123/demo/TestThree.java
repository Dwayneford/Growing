package com.yc123.demo;

import java.util.TreeSet;

public class TestThree {
	public static void main(String[] args) {
		String strs = "zxcvbasdfg";
		//ת��char ����
		char[] chaarry =strs.toCharArray();
		
		TreeSet tchar = new TreeSet();
		
		for (char c : chaarry) {
			tchar.add(c);
		}
		
		for (Object chaEnt : tchar) {
			System.out.println(chaEnt);
		}
		
		
	}
}
