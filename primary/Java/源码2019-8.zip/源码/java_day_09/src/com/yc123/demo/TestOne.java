package com.yc123.demo;

import java.util.Comparator;
import java.util.TreeSet;

public class TestOne {

	public static void main(String[] args) {
		TreeSet ts = new TreeSet(new StrLenComparator());
		ts.add("abcd");
		ts.add("cc");
		ts.add("cba");
		ts.add("aaa");
		ts.add("z");
		ts.add("hahaha");
		
		for (Object str : ts) {
			System.out.println(str);
		}
	}
}

class StrLenComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		//�Լ�д �Ƚ��߼�
		String s1 = (String)o1;
		String s2 = (String)o2;
		
		//�жϳ���
		/*
		int numLen = s1.length();
		int numLen2 = s2.length();
		int retNum = (numLen-numLen2);*/
		
		int numLen = new Integer(s1.length()).compareTo(new Integer(s2.length()));
		if(numLen==0){
			return s1.compareTo(s2);
		}
		return numLen;
	}
	
	
}
