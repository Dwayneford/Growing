package com.yc123.jdbc;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.ResourceBundle;

public class JdbcUtil {
	public static void main(String[] args) throws Exception {
		JdbcUtil ju = new JdbcUtil();
		ju.getConn();
	}
	
	public void getConn() throws Exception{
		//��ʽ����ȡ�������ݿ�ľ�̬ ����
		ResourceBundle rb =	ResourceBundle.getBundle("jdbc");
		
		String url = rb.getString("url");
		String user = rb.getString("user");
		String className=  rb.getString("className");
		String password =  rb.getString("password");
		
		//��ʽ��
		InputStream in= this.getClass().getClassLoader().getResourceAsStream("jdbc.properties");
		//�����ļ��� ��ȡ�ļ�������
		Properties properties = new Properties();
		properties.load(in);
		//ȡ����Ӧ������ֵ
		String url1 = properties.getProperty("url");
		String user1 = properties.getProperty("user");
		String className1=  properties.getProperty("className");
		String password1 =  properties.getProperty("password");
		
		try {
			Class.forName(className1);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection conn = null;
		//��ȡ���Ӷ���
		try {
			conn =	DriverManager.getConnection(url1, user1, password1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println("conn"+conn);
		
		
	}
	
	
}
