package com.yc123.ent;

import java.io.Serializable;

public class GoodsEnt implements Serializable{
	private int goodsNo;
	private String goodsName;
	private String goodsType;
	private double goodsPrice;
	public int getGoodsNo() {
		return goodsNo;
	}
	public void setGoodsNo(int goodsNo) {
		this.goodsNo = goodsNo;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getGoodsType() {
		return goodsType;
	}
	public void setGoodsType(String goodsType) {
		this.goodsType = goodsType;
	}
	public double getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(double goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	
	public GoodsEnt(int goodsNo, String goodsName, String goodsType, double goodsPrice) {
		super();
		this.goodsNo = goodsNo;
		this.goodsName = goodsName;
		this.goodsType = goodsType;
		this.goodsPrice = goodsPrice;
	}
	public GoodsEnt() {
		super();
	}
	@Override
	public String toString() {
		return "GoodsEnt [goodsNo=" + goodsNo + ", goodsName=" + goodsName + ", goodsType=" + goodsType
				+ ", goodsPrice=" + goodsPrice + "]";
	}
	
}
