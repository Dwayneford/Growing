package com.yc123.demo;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
public class Test_05 {
	public static void main(String[] args) {
		//定义集合类变量
		List<? extends Fruits> fruits;
		
		//使用集合类变量 ，接收具体对象
		fruits = new ArrayList<Apple>();
		fruits = new LinkedList<Fruits>();
		fruits = new ArrayList<Banner>();
		
		//超出父类的基类集合 无法 通过fruits 接收;
		//fruits = new LinkedList<Object>();
		
		//存放值
		// fruits.add(new Apple()); // 编译无法通过；
		ArrayList<Apple> arryApp = new ArrayList<Apple>();
		arryApp.add(new Apple());
		arryApp.add(new Apple());
		arryApp.add(new Apple());
		fruits= arryApp;
		
		//取值
		fruits.get(0);
	}
}
class Fruits{
	
}
class Apple extends Fruits{
	
}
class Banner extends Fruits{
	
}

