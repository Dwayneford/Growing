package MyJAVA.JAVA_06异常;

public class 异常 {

}
/*

Error是程序无法处理的错误，表示运行应用程序中较严重问题

finally语句块只有一种情况是不会执行的，那就是在执行finally之前遇到了System.exit(0)结束程序运行

      --ArithmeticException

      --NullPointerException

      --ClassCastException

      --ArrayIndexOutOfBoundsException

      --NumberFormatException















*/