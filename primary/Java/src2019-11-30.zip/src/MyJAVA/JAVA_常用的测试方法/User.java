package MyJAVA.JAVA_常用的测试方法;
/**
 * 多个变量指向同一个对象
 * @author Administrator
 *
 */
public class User {
    int id;        //id
    String name;   //账户名
    String pwd;   //密码
       
    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }
      
    public   void   testParameterTransfer01(User  u){
        u.name="属性赋值";
    }
     
    public   void   testParameterTransfer02(User  u){
        u  =  new  User(200,"新建对象赋值");
    }
      
    public static void main(String[] args) {
        User   u1  =  new User(100, "新对象");
         
        u1.testParameterTransfer01(u1); 
        System.out.println(u1.name);
 
        u1.testParameterTransfer02(u1);
        System.out.println(u1.name);
    }
}
