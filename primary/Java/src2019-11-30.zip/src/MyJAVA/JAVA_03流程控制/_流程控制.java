package MyJAVA.JAVA_03流程控制;

public class _流程控制 {
	public static void main(String[] args) {
		for(int i = 1, j = i + 10; i < 5; i++, j = i * 2) {
            System.out.println("i= " + i + " j= " + j); 
        } 
//		i= 1 j= 11
//		i= 2 j= 4
//		i= 3 j= 6
//		i= 4 j= 8
		for (int i = 0 , j= 10; i < 5; i++,j++) {
			System.out.println("i="+i+";"+"j="+j);
		}
		//控制表达式的初始化和步进控制部分，我们可以使用一系列由逗号分隔的表达式，而且那些表达式均会独立执行。
		//递归:
		System.out.println("递归结果:"+digui(10));
		System.out.println("迭代结果:"+diedai(10));
	}
	//递归方法，计算n的阶乘
	private static long digui(int n){
		if (n==1) {
			return 1 ;
		}else {
			return n*digui(n-1);
		}
	}
	
	//迭代方法，计算n的阶乘
	private static long diedai(int n){
		int result = 1 ;
		while (n>1) {
			result *= n ;
			n -=1 ;
		}
		return result;
	}
	
	
}
/*

顺序、选择和循环
	“顺序结构”代表“先执行a，再执行b”的逻辑。
	“选择结构”代表“如果…，则…”的逻辑。
	“循环结构”代表“如果…，则再继续…”的逻辑。
	
顺序结构
选择结构
	if单选择结构
	if-else双选择结构
	if-else if-else多选择结构
	switch结构

	if单选择结构	
		if(布尔表达式){
			语句块
		}
		如果if语句不写{}，则只能作用于后面的第一条语句
		
	if-else双选择结构
		if(布尔表达式){
			语句块1
		}else{
			语句块2
		}
		
	if-else if-else多选择结构
		if(布尔表达式1) {
			语句块1;
		} else if(布尔表达式2) {
			语句块2;
		}……
		else if(布尔表达式n){
			语句块n;
		} else {
			语句块n+1;
		}		

	switch结构
		switch (表达式) {
		case 值1: 
			语句序列1;
		[break];
		case 值2:
		 	语句序列2;
		[break];
		     … … …      … …
		[default:
		 	默认语句;]
		}
		switch语句会根据表达式的值从相匹配的case标签处开始执行，
		一直执行到break语句处或者是switch语句的末尾。
		如果表达式的值与任一case值不匹配，则进入default语句(如果存在default语句的情况)


	break是用来跳出循环的，例如for，while，do-while都可以跳出，但不跳出函数
		可使程序终止循环而执行循环后面的语句
	return是使整个函数返回的，后面的不管是循环里面还是循环外面的都不执行
		将函数的值返回主调函数	
	continue语句的作用是跳过循环本中剩余的语句而强行执行下一次循环。
		加速循环
循环结构
	while循环
	do-while循环
	for循环
	嵌套循环

	while循环
		while (布尔表达式) {
			循环体;
		}
		语句中应有使循环趋向于结束的语句（int i <= 100）
		
	do-while循环
		do {
			循环体;
	     } while(布尔表达式) ;
		do-while循环的循环体至少执行一次

	for循环
		for (初始表达式; 布尔表达式; 迭代因子) {
			循环体;
		}
		
嵌套循环		
	在一个循环语句内部再嵌套一个或多个循环，称为嵌套循环。while、do-while与for循环可以任意嵌套多层。
		
无限循环
	while(true)与for(;;)

递归结构recursion
	递归的基本思想就是“自己调用自己”，一个使用递归技术的方法将会直接或者间接的调用自己。
	
	递归结构包括两个部分：

      1.定义递归头。解答：什么时候不调用自身方法。如果没有头，将陷入死循环，也就是递归的结束条件。

      2.递归体。解答：什么时候需要调用自身方法。
		
	简单的程序是递归的优点之一
	但是递归调用会占用大量的系统堆栈，内存耗用多，在递归调用层次多时速度要比循环慢的多
	
迭代结构iterate
	迭代就是A不停的调用B
	
	

*/