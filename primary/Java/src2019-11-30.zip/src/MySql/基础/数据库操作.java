package MySql.基础;

public class 数据库操作 {

}
/*

-- 新增类
-- 创建数据库
create database testDataBase default character set utf8
-- 切换到数据库
use testDataBase 
-- 建表
create table testTable (id int(10) not null primary key auto_increment comment 'ID注释',
												name varchar(20) comment '姓名',
												time timestamp comment '时间'
)charset=utf8,engine=innodb,comment='此表为测试表';
-- 增加字段
alter table testTable add column testField varchar(20)
-- 插入数据
insert into testtable value(null,'zhangsan','asd'),(null,'zhaowu','fggf')
insert into testtable(name,testField) values ('lisi','asd')

CREATE TABLE Persons
(
PersonID int,
LastName varchar(255),
FirstName varchar(255),
Address varchar(255),
City varchar(255)
);



-- 删除类
-- 删除库
drop database testDataBase2
-- 删表
drop table testtable2
-- 删除表的所有数据
delete from testTable
-- 删除表的列
alter table testtable drop column testfield2
-- 删除表的某行
delete from testtable where id=2

-- 修改类
-- 修改表名
alter table testtable2 rename to testtable
-- 修改列名 
alter table testtable change testfield testfields varchar(30)
-- 修改某行
update testtable set name='updatename' where id=1

-- 查询类
-- 返回不同且唯一的值
select distinct name from testtable
select *from websites order by alexa desc 	-- 降序排列
select * from websites where alexa >15 and (country="cn" or country='usa')


-- 规定要返回的记录的数目
SELECT * FROM Websites LIMIT 2;

-- 模糊搜索，"%" 为通配符
SELECT * FROM Websites  WHERE name LIKE '%k%';

-- not 关键字
SELECT * FROM Websites WHERE name NOT LIKE '%k%';

-- 				%										替代 0 个或多个字符
-- 				_										替代一个字符
-- 		[charlist]							字符列中的任何单一字符
-- [^charlist]或[!charlist]		不在字符列中的任何单一字符


-- IN 操作符允许在 WHERE 子句中规定多个值
SELECT * FROM Websites WHERE name IN ('Google','菜鸟教程');


-- BETWEEN 操作符用于选取介于两个值之间的数据范围内的值
SELECT * FROM Websites WHERE alexa BETWEEN 1 AND 20;

SELECT * FROM Websites WHERE alexa NOT BETWEEN 1 AND 20;


SELECT * FROM Websites WHERE (alexa BETWEEN 1 AND 20) AND country NOT IN ('USA', 'IND');


SELECT * FROM access_log
WHERE date BETWEEN '2016-05-10' AND '2016-05-14';


SELECT name, CONCAT(url, ', ', alexa, ', ', country) AS site_info  FROM Websites;


SELECT w.name, w.url, a.count, a.date 
FROM Websites AS w, access_log AS a 
WHERE a.site_id=w.id and w.name="菜鸟教程";



-- JOIN
-- INNER JOIN 交叉的部分
SELECT Websites.id, Websites.name, access_log.count, access_log.date
FROM Websites
INNER JOIN access_log
ON Websites.id=access_log.site_id;

-- INNER JOIN 关键字在表中存在至少一个匹配时返回行
SELECT Websites.name, access_log.count, access_log.date
FROM Websites
INNER JOIN access_log
ON Websites.id=access_log.site_id
ORDER BY access_log.count;


-- LEFT JOIN 关键字从左表（Websites）返回所有的行，即使右表（access_log）中没有匹配
-- 右表中没有匹配
SELECT Websites.name, access_log.count, access_log.date
FROM Websites
LEFT JOIN access_log
ON Websites.id=access_log.site_id
ORDER BY access_log.count DESC;


-- RIGHT JOIN 关键字从右表（Websites）返回所有的行，即使左表（access_log）中没有匹配
SELECT Websites.name, access_log.count, access_log.date
FROM access_log
RIGHT JOIN Websites
ON access_log.site_id=Websites.id
ORDER BY access_log.count DESC;


-- SQL UNION 操作符合并两个或多个 SELECT 语句的结果
SELECT country FROM Websites
UNION
SELECT count FROM access_log
ORDER BY country;


-- 创建 Websites 的备份复件
SELECT *
INTO WebsitesBackup2016
FROM Websites;


-- 只复制一些列插入到新表中：
SELECT name, url
INTO WebsitesBackup2016
FROM Websites;

-- 只复制中国的网站插入到新表中：
SELECT *
INTO WebsitesBackup2016
FROM Websites
WHERE country='CN';

-- 复制多个表中的数据插入到新表中：
SELECT Websites.name, access_log.count, access_log.date
INTO WebsitesBackup2016
FROM Websites
LEFT JOIN access_log
ON Websites.id=access_log.site_id;


-- 约束
-- NOT NULL - 指示某列不能存储 NULL 值。
-- UNIQUE - 保证某列的每行必须有唯一的值。
-- PRIMARY KEY - NOT NULL 和 UNIQUE 的结合。确保某列（或两个列多个列的结合）有唯一标识，有助于更容易更快速地找到表中的一个特定的记录。
-- FOREIGN KEY - 保证一个表中的数据匹配另一个表中的值的参照完整性。
-- CHECK - 保证列中的值符合指定的条件。
-- DEFAULT - 规定没有给列赋值时的默认值。

-- 添加约束
ALTER TABLE Persons MODIFY Age int NOT NULL;


-- 在 "P_Id" 列创建 UNIQUE 约束
ALTER TABLE Persons
ADD CONSTRAINT uc_PersonID UNIQUE (P_Id,LastName)

-- 删除unique约束
ALTER TABLE Persons
DROP INDEX uc_PersonID

constraint

-- 增加主键
ALTER TABLE Persons
ADD PRIMARY KEY (P_Id)

ALTER TABLE Persons
DROP PRIMARY KEY

-- 外键foreign pefernces
CREATE TABLE Orders
(
O_Id int NOT NULL,
OrderNo int NOT NULL,
P_Id int,
PRIMARY KEY (O_Id),
FOREIGN KEY (P_Id) REFERENCES Persons(P_Id)
)


-- 增加外键
ALTER TABLE Orders
ADD FOREIGN KEY (P_Id)
REFERENCES Persons(P_Id)


ALTER TABLE Orders
DROP FOREIGN KEY fk_PerOrders


-- CHECK 约束用于限制列中的值的范围

ALTER TABLE Persons
ADD CHECK (P_Id>0)


-- 设置默认值
ALTER TABLE Persons
ALTER City SET DEFAULT 'SANDNES'


引索
CREATE INDEX index_name
ON table_name (column_name)






ALTER TABLE table_name DROP INDEX index_name

DROP TABLE table_name

DROP DATABASE database_name
-- 仅删数据不删表
TRUNCATE TABLE table_name






ALTER TABLE table_name
ADD column_name datatype


ALTER TABLE table_name
DROP COLUMN column_name

ALTER TABLE table_name
MODIFY COLUMN column_name datatype




ALTER TABLE Persons AUTO_INCREMENT=100

-- 视图
CREATE VIEW view_name AS
SELECT column_name(s)
FROM table_name
WHERE condition

CREATE VIEW view_test AS
SELECT url
FROM websites
WHERE condition



-- DATE - 格式：YYYY-MM-DD
-- DATETIME - 格式：YYYY-MM-DD HH:MM:SS
-- TIMESTAMP - 格式：YYYY-MM-DD HH:MM:SS
-- YEAR - 格式：YYYY 或 YY













*/