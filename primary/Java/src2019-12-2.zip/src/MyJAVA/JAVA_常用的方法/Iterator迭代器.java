package MyJAVA.JAVA_常用的方法;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Iterator迭代器 {

	public  void 总结() {
		
		List<String> list = null;
		//普通for循环遍历list
		for(int i=0;i<list.size();i++){//list为集合的对象名
		    String temp = (String)list.get(i);
		    System.out.println(temp);
		}
	
	
		//增强for遍历list
		for (String temp : list) {
			System.out.println(temp);
			}
	
		//使用迭代器1遍历list
		for(Iterator iter= list.iterator();iter.hasNext();){
		    String temp = (String)iter.next();
		    System.out.println(temp);
		}
	
		//使用迭代器2遍历list
		Iterator  iter =list.iterator();
		while(iter.hasNext()){
		    Object  obj =  iter.next();
		    iter.remove();//如果要遍历时，删除集合中的元素，建议使用这种方式！
		    System.out.println(obj);
		}
	
	
		//增强for循环遍历set
		HashSet<String> set = null;
		for(String temp:set ){
			System.out.println(temp);
			}
	
		
		//使用迭代器遍历set
		for(Iterator iter1 = set.iterator();iter1.hasNext();){
		    String temp = (String)iter1.next();
		    System.out.println(temp);
		}
	
		//根据key获取value遍历map
		Map<Integer, Man> maps = new HashMap<Integer, Man>();
		Set<Integer>  keySet =  maps.keySet();
		for(Integer id : keySet){
		System.out.println(maps.get(id).name);
		}
		
		//使用entrySet遍历map
		Set<Entry<Integer, Man>>  ss = maps.entrySet();
		for (Iterator iterator = ss.iterator(); iterator.hasNext();) {
		    Entry e = (Entry) iterator.next(); 
		    System.out.println(e.getKey()+"--"+e.getValue());
		
		}
		
		
		
		
		
	}
	
	public void 迭代器遍历list	(){
		List<String> aList = new ArrayList<String>();
        for (int i = 0; i < 5; i++) {
            aList.add("a" + i);
        }
        System.out.println(aList);
        for (Iterator<String> iter = aList.iterator(); iter.hasNext();) {
            String temp = iter.next();
            System.out.print(temp + "\t");
            if (temp.endsWith("3")) {// 删除3结尾的字符串
                iter.remove();
            }
        }
        System.out.println();
        System.out.println(aList);
    }
		
	public void 迭代器遍历Set	(){
		Set<String> set = new HashSet<String>();
        for (int i = 0; i < 5; i++) {
            set.add("a" + i);
        }
        System.out.println(set);
        for (Iterator<String> iter = set.iterator(); iter.hasNext();) {
            String temp = iter.next();
            System.out.print(temp + "\t");
        }
        System.out.println();
        System.out.println(set);
    }
	
	public void 迭代器遍历Map1	(){
		Map<String, String> map = new HashMap<String, String>();
        map.put("A", "高淇");
        map.put("B", "高小七");
        Set<Entry<String, String>> ss = map.entrySet();
        for (Iterator<Entry<String, String>> iterator = ss.iterator(); iterator.hasNext();) {
            Entry<String, String> e = iterator.next();
            System.out.println(e.getKey() + "--" + e.getValue());
        }
    }
	
	public void 迭代器遍历Map2	(){
		Map<String, String> map = new HashMap<String, String>();
        map.put("A", "高淇");
        map.put("B", "高小七");
        Set<String> ss = map.keySet();
        for (Iterator<String> iterator = ss.iterator(); iterator.hasNext();) {
            String key = iterator.next();
            System.out.println(key + "--" + map.get(key));
        }
    }
	
	
	
}

class Man {
	
	String name ;
}
