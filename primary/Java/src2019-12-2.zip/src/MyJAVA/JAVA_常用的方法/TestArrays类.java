package MyJAVA.JAVA_常用的方法;

import java.util.Arrays;

public class TestArrays类 {

	public static void main(String[] args) {
		int a[] = {85,2,42,65,35,73};
		System.out.println(a);
		//打印数组元素的值
		System.out.println(Arrays.toString(a));
		
		System.out.println("给数组排序");
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
		
		System.out.println("数组的填充");
		Arrays.fill(a, 2, 4, 100);
		System.out.println(Arrays.toString(a));
		
		System.out.println("二分法查找");
		Arrays.sort(a);
		System.out.println("先排序"+Arrays.toString(a));
		System.out.println("该元素的引索:"+Arrays.binarySearch(a, 85));
		
		
		
		//数组元素是引用类型的排序(Comparable接口的应用)
		//实现Comparable接口，重写compareto方法
		
	}
	
	
	
}
