package MyJAVA.JAVA_常用的方法;

public class Test数组的拷贝 {

	public static void main(String[] args) {
		String [] arr = {"阿里巴巴","网易","腾讯","百度","华为"};
		
		String[] arrCopy = new String [7] ;
		/**
		 * 数组的拷贝
		 * src原数组，起始位置，dest目标数组，起始位置，长度
		 * 
		 */
//		System.arraycopy(src, srcPos, dest, destPos, length);
		System.arraycopy(arr, 0, arrCopy, 1, 5);
		for (String temp : arrCopy) {
			System.out.println(temp);
		}
		
		
		
	}
	
	
}
