package MyJAVA.JAVA_02数据类型和运算符;

import java.math.BigDecimal;

public class _01数据类型和运算符 {
	
	public static void main(String[] args) {
		
		BigDecimal bd = BigDecimal.valueOf(1.0);
        bd = bd.subtract(BigDecimal.valueOf(0.1));
        bd = bd.subtract(BigDecimal.valueOf(0.1));
        bd = bd.subtract(BigDecimal.valueOf(0.1));
        bd = bd.subtract(BigDecimal.valueOf(0.1));
        bd = bd.subtract(BigDecimal.valueOf(0.1));
        System.out.println(bd);//0.5
		
		System.out.println(1.0 - 0.1 - 0.1 - 0.1 - 0.1 - 0.1);//0.5000000000000001
	}

}
/*
1、变量：变量本质上就是代表一个”可操作的存储空间”，空间位置是确定的，但是里面放置什么值不确定。
	声明变量：
	double  salary;
	double  e = 2.718281828;
	long  earthPopulation;
	int  age;
2、变量的分类
	局部变量：位置：方法或语句块内部，从属于：方法/语句块，生命周期：从声明位置开始，直到方法或语句块执行完毕，局部变量消失
	成员变量：位置：类内部，方法外部，从属于：对象，	   生命周期：对象创建，成员变量也跟着创建。对象消失，成员变量也跟着消失；
	静态变量：位置：类内部，static修饰从属于：类，	   生命周期：类被加载，静态变量就有效；类被卸载，静态变量消失。
	(成员变量=实例变量)(静态变量=类变量)
3、常量：由final修饰，一旦赋值，就不能被修改

4、数据类型：
 Java的数据类型可分为两大类：基本数据类型（primitive data type）和引用数据类型（reference data type）。

Java中定义了3类8种基本数据类型
	基本数据类型：
		数值型－ byte（整1）、 short（整2）、int（整4）、 long（整8）、float（浮4）、 double（浮8）
		
		字符型－ char(2Byte)
		
		布尔型－boolean(1位bit) 
	引用数据类型（引用数据类型的大小统一为4个字节，记录的是其引用对象的地址！）
		类
		接口
		数组
		
	float类型又被称作单精度类型，尾数可以精确到7位有效数字，double为两倍
 	因此，不能使用浮点数进行比较！BigDecimal
 	(float f = 0.1f)!=(double d = 1.0/10);
	(float d1 = 423432423f)==(float d2 = d1+1)（超过了7位）

	
char字符型在内存中占2个字节，在Java中使用单引号来表示字符常量,(’A’)!=(”A”)
8位  	 = 1字节
8bit = 1Byte  1byte存1个英文字母，2个byte存一个汉字

转义字符 ‘\’ 来将其后的字符转变为其它的含义


byte	1字节		-27 ~  27-1（-128~127）

short	2字节		-215 ~  215-1 （-32768~32767）

int		4字节		-231 ~  231-1 (-2147483648~2147483647) 约21亿

long	8字节		-263 ~  263-1




*/