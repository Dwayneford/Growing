package MyJAVA.JAVA_10IO流;

public class IO {

}
/*

按流的方向分类：

  1. 输入流：数据流向是数据源到程序(以InputStream、Reader结尾的流)。

  2. 输出流：数据流向是程序到目的地(以OutPutStream、Writer结尾的流)。


按处理的数据单元分类：

  1. 字节流：以字节为单位获取数据，命名上以Stream结尾的流一般是字节流，如FileInputStream、FileOutputStream。

  2. 字符流：以字符为单位获取数据，命名上以Reader/Writer结尾的流一般是字符流，如FileReader、FileWriter。


按处理对象不同分类：

  1. 节点流：可以直接从数据源或目的地读写数据，如FileInputStream、FileReader、DataInputStream等。

  2.  处理流：不直接连接到数据源或目的地，是”处理流的流”。通过对其他流的处理提高程序的性能，如BufferedInputStream、BufferedReader等。处理流也叫包装流。


总结
   1. InputStream/OutputStream

        字节流的抽象类。

     2. Reader/Writer

        字符流的抽象类。

     3. FileInputStream/FileOutputStream

        节点流：以字节为单位直接操作“文件”。

     4. ByteArrayInputStream/ByteArrayOutputStream

        节点流：以字节为单位直接操作“字节数组对象”。

     5. ObjectInputStream/ObjectOutputStream

        处理流：以字节为单位直接操作“对象”。

     6. DataInputStream/DataOutputStream

        处理流：以字节为单位直接操作“基本数据类型与字符串类型”。

     7. FileReader/FileWriter

        节点流：以字符为单位直接操作“文本文件”(注意：只能读写文本文件)。

     8. BufferedReader/BufferedWriter

        处理流：将Reader/Writer对象进行包装，增加缓存功能，提高读写效率。

     9. BufferedInputStream/BufferedOutputStream

        处理流：将InputStream/OutputStream对象进行包装，增加缓存功能，提高 读写效率。

     10. InputStreamReader/OutputStreamWriter

        处理流：将字节流对象转化成字符流对象。

     11. PrintStream

        处理流：将OutputStream进行包装，可以方便地输出字符，更加灵活。


把Java对象转换为字节序列的过程称为对象的序列化。把字节序列恢复为Java对象的过程称为对象的反序列化。


fileUtil
IOUtil




*/