package MyJAVA.JAVA_常用的方法;
/*

“==”代表比较双方是否相同。如果是基本类型则表示值相等，如果是引用类型则表示地址相等即是同一个对象。
object下的equals没有重写，和==没有区别，
String下的equals重写了，先比较是否是同一个对象，是字符串时，将字符串转为char数组，比较两个数组的值是否相等。

*/
public class Test等等和Equals {

	public static void main(String[] args) {
        Person2 p1 = new Person2(123,"张三");
        Person2 p2 = new Person2(123,"李四");  
        System.out.println("p1==p2:");
        System.out.println(p1==p2);     //false，比较地址，不是同一个对象
       
        System.out.println("p1.equals(p2):");
        System.out.println(p1.equals(p2));  //true，重写了equals方法，id相同则认为两个对象内容相同
       
        System.out.println("p1.equals2(p2):");
        System.out.println(p1.equals2(p2));
        String s1 = new String("王五");
        String s2 = new String("王五");
        
        System.out.println("s1==s2:"); 
        System.out.println(s1==s2);         //false, 两个字符串不是同一个对象
        System.out.println("s1.equals(s2):");
        System.out.println(s1.equals(s2));  //true,  两个字符串内容相同
        
        System.out.println("**********************");
        String str1 = "123";
        String str2 = "123";
        System.out.println(str1 == str2);
        System.out.println(str1.equals(str2));
    }
}
class Person2 {
    int id;
    String name;
    public Person2(int id,String name) {
        this.id=id;
        this.name=name;
    }
    public boolean equals2(Object obj) {
        if(obj == null){
            return false;
        }else {
            if(obj instanceof Person2) {
                Person2 c = (Person2)obj;
                if(c.id==this.id) {
                    return true;
                }
            }
        }
		return false;
    }
}


