package MyJAVA.JAVA_08常用类;

public class Math类 {

}
/*

Math类的常用方法：

      1. abs 绝对值

      2. acos,asin,atan,cos,sin,tan 三角函数

      3. sqrt 平方根

      4. pow(double a, double b) a的b次幂

      5. max(double a, double b) 取大值

      6. min(double a, double b) 取小值

      7. ceil(double a) 大于a的最小整数

      8. floor(double a) 小于a的最大整数

      9. random() 返回 0.0 到 1.0 的随机数

      10. long round(double a) double型的数据a转换为long型(四舍五入)

      11. toDegrees(double angrad) 弧度->角度

      12. toRadians(double angdeg) 角度->弧度








*/
