package MyJAVA.JAVA_08常用类;

public class 包装类 {

}
/*

转integer，
	int：
	integer int1 = new integer（20）;
	integer int2 = integer.valueOf(20);
	String:
	integer int3 = new integer("333");
	integer int4 = integer.parseInt("333")
	
转int
	int a = int1.intValue();
转String
	String b = int2.toString();


      1. String：不可变字符序列。

      2. StringBuffer：可变字符序列，并且线程安全，但是效率低。

      3. StringBuilder：可变字符序列，线程不安全，但是效率高(一般用它)。








*/