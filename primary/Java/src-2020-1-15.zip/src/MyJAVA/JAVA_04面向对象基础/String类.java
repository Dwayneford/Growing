package MyJAVA.JAVA_04面向对象基础;

public class String类 {

}
/*

全局字符串常量池(String Pool)

class文件常量池(Class Constant Pool)

运行时常量池(Runtime Constant Pool)

常用方法
	
	charat（int index）
	equals（String other）
	equalsIgnoreCase（String other）
	indexOf(String str)
	lastIndexOf(String str)
	length()
	replace(char oldChar , char newChar)
	stratsWith(String prefix)
	endsWith(String prefix)
	subString(int beginIndex)
	subString(int beginIndex , int endIndex)
	toLowerCase()
	toUpCase()
	trim()


开闭原则
	
	对扩展开放
		应对需求变化要灵活。 要增加新功能时，不需要修改已有的代码，增加新代码即可
	
	对修改关闭
		核心部分经过精心设计后，不再因为需求变化而改变




*/