package MyJAVA.设计模式.原型模式PrototypePattern.类;

public class Circle extends Shape {
	 
   public Circle(){
     type = "Circle";
   }
 
   @Override
   public void draw() {
      System.out.println("Inside Circle::draw() method.");
   }
}
