package MyJAVA.设计模式.原型模式PrototypePattern.类;

public class Square extends Shape {
	 
   public Square(){
     type = "Square";
   }
 
   @Override
   public void draw() {
      System.out.println("Inside Square::draw() method.");
   }
}