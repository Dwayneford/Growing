package MyJAVA.设计模式.原型模式PrototypePattern.类;

import java.util.Hashtable;

public class ShapeCache {

	private static Hashtable<String, Shape> shapeMap 
		= new Hashtable<String, Shape>();
	//通过ID获取对象，返回一个副本对象
	public static Shape getShape (String shapeId) throws CloneNotSupportedException{
		Shape cachedShape = shapeMap.get(shapeId);
		return (Shape) cachedShape.clone();
	}
	//一次性将对象加载并缓存
	public static void loadCache (){
		Circle circle = new Circle();
		circle.setId("1");
		shapeMap.put(circle.getId(), circle);
		
		Square square = new Square();
		square.setId("2");
		shapeMap.put(square.getId(), square);
		
		Rectangle rectangle = new Rectangle();
		rectangle.setId("3");
		shapeMap.put(rectangle.getId(), rectangle);
		
		
	}
	
	
	
	
	
	
	
}
