package MyJAVA.设计模式.原型模式PrototypePattern.类;

public class PrototypePatternDemo {

	public static void main(String[] args) throws CloneNotSupportedException {
		ShapeCache.loadCache();
		
		Shape cloneShape = ShapeCache.getShape("1");
		System.out.println("Shape = " + cloneShape.getType());
		
	    Shape clonedShape2 = ShapeCache.getShape("2");
	    System.out.println("Shape = " + clonedShape2.getType());        
 
	    Shape clonedShape3 = ShapeCache.getShape("3");
      	System.out.println("Shape = " + clonedShape3.getType());   
		
		
	}
	
	
}
