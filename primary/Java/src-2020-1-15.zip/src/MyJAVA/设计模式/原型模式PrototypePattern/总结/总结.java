package MyJAVA.设计模式.原型模式PrototypePattern.总结;

public class 总结 {

}
/*

1类需要实现Cloneable
2缓存容器，包含hashtable，存放对象的方法，获取对象的方法


用在缓存容器中，利用Hashtable将对象保存起来，对外提供通过key获取获取对象（clone）的方法

从缓存中复制对象，可以减少数据库连接










*/