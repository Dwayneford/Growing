package MyJAVA.设计模式.桥接模式Bridge.实体类;

import MyJAVA.设计模式.桥接模式Bridge.DrawAPI;

public class GreenCircle implements DrawAPI{

	@Override
	public void drawCircle(int radius, int x, int y) {
		System.out.println("Draw Circle: color = Green , redius = "+radius+
				" , x = " + " , y = "+y);
		
	}

}
