package MyJAVA.设计模式.桥接模式Bridge;

import MyJAVA.设计模式.桥接模式Bridge.实体类.GreenCircle;
import MyJAVA.设计模式.桥接模式Bridge.实体类.RedCircle;

public class BridgePatternDemo {
	public static void main(String[] args) {
		Shape redCircle = new Circle(new RedCircle(), 100, 100, 10);
		Shape greenCircle = new Circle( new GreenCircle() ,100,100, 10);
		
		redCircle.draw();
		greenCircle.draw();
	}
}
