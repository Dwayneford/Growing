package MyJAVA.设计模式.桥接模式Bridge;

public abstract class Shape {
	protected DrawAPI drawAPI ;

	public Shape(DrawAPI drawAPI) {
		super();
		this.drawAPI = drawAPI;
	}
	public abstract void draw ();
	
}
