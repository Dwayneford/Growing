package MyJAVA.设计模式.桥接模式Bridge;

public interface DrawAPI {
	public void drawCircle(int radius , int x, int y);
}
