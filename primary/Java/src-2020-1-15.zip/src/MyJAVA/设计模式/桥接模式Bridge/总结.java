package MyJAVA.设计模式.桥接模式Bridge;

public class 总结 {

}
/*

桥接模式

两个独立变化的维度，通过构造器传入另一个接口，使用其中的方法

抽象类依赖实现类



*/