package MyJAVA.设计模式.适配器模式.实体类;

import MyJAVA.设计模式.适配器模式.Adapter_Pattern.AdvanceMediaPlayer;

public class Mp4Player implements AdvanceMediaPlayer{

	@Override
	public void playVlc(String fileName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void palyMp4(String fileName) {
		System.out.println("Mp4Player , playing Mp4 file Name = "+ fileName);		
	}

}
