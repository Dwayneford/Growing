package MyJAVA.设计模式.适配器模式.实体类;

import MyJAVA.设计模式.适配器模式.Adapter_Pattern.AdvanceMediaPlayer;

public class VlcPlayer implements AdvanceMediaPlayer{

	@Override
	public void playVlc(String fileName) {
		System.out.println("VlcPlayer,Playing vlc file ,name = "+ fileName);
		
	}

	@Override
	public void palyMp4(String fileName) {
		
	}

}
