package MyJAVA.设计模式.适配器模式.实体类;

import MyJAVA.设计模式.适配器模式.Adapter_Pattern.MediaPlayer;
import MyJAVA.设计模式.适配器模式.适配器.MediaAdapter;

public class AudioPlayer implements MediaPlayer{

	private MediaAdapter mediaAdapter ;
	
	@Override
	public void play(String audioType, String fileName) {
		//播放MP3文件内置支持
		if (audioType.equalsIgnoreCase("mp3")) {
			System.out.println("AudioPlayer , Playing mp3 file. Name =" + fileName);
		}else if (audioType.equalsIgnoreCase("vlc")
				|| audioType.equalsIgnoreCase("mp4")) {
			mediaAdapter = new MediaAdapter(audioType);
			mediaAdapter.play(audioType, fileName);
		}else {
			System.out.println("Invalid media. "+
		            audioType + " format not supported");
		}
		
	}

}
