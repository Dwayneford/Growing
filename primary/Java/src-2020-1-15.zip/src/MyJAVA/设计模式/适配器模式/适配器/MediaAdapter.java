package MyJAVA.设计模式.适配器模式.适配器;

import MyJAVA.设计模式.适配器模式.Adapter_Pattern.AdvanceMediaPlayer;
import MyJAVA.设计模式.适配器模式.Adapter_Pattern.MediaPlayer;
import MyJAVA.设计模式.适配器模式.实体类.Mp4Player;
import MyJAVA.设计模式.适配器模式.实体类.VlcPlayer;

public class MediaAdapter implements MediaPlayer{
	private AdvanceMediaPlayer advanceMediaPlayer ;
	
	
	public MediaAdapter(String audioType) {
		if (audioType.equalsIgnoreCase("vlc")) {
			advanceMediaPlayer = new VlcPlayer();
		}else if (audioType.equalsIgnoreCase("Mp4")) {
			advanceMediaPlayer = new Mp4Player();
		}
	}


	@Override
	public void play(String audioType, String fileName) {
		if (audioType.equalsIgnoreCase("mp4")) {
			advanceMediaPlayer.palyMp4(fileName);
		}else if (audioType.equalsIgnoreCase("vlc")) {
			advanceMediaPlayer.playVlc(fileName);
		}
		
		
		
		
		
	}
	
	

}
