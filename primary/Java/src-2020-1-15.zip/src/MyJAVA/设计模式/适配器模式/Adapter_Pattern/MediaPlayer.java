package MyJAVA.设计模式.适配器模式.Adapter_Pattern;

public interface MediaPlayer {
	public void play(String audioType , String fileName);

}
