package MyJAVA.设计模式.适配器模式.Adapter_Pattern;

public class 总结 {

}
/*
适配器模式

适配器：在一定情况下，调用其他接口处理逻辑

两个主接口，适配器实现一个接口，用它调用另外一个接口










*/