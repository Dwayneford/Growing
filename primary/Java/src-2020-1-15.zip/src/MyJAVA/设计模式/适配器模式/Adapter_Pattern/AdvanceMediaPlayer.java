package MyJAVA.设计模式.适配器模式.Adapter_Pattern;

public interface AdvanceMediaPlayer {
	public void playVlc(String fileName);
	public void palyMp4(String fileName);
}
