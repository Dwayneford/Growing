package MyJAVA.设计模式.建造者模式BuilderPattern;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类.Coke;
import MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类.Pepsi;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.ZeroI;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.接口.Item;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类.ChickenBurger;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类.VegBurger;
//套餐建造者，负责向容器添加组员，组成套餐
public class MealBuilder {

	public Meal prepareVegMeal(){
		Meal meal = new Meal();
		meal.addItem(new VegBurger());
		meal.addItem(new Coke());
		return meal;
	}
	
	public Meal pripareNonVegMeal(){
		Meal meal = new Meal();
		meal.addItem(new ChickenBurger());
		meal.addItem(new Pepsi());
		return meal ;
	}
	
	public Meal addItems(Item ... item ){
		Meal meal = new Meal();
		if (item != null) {
			for (Item temp : item) {
				meal.addItem(temp);
			}
		}
		return meal ;
	}
	
	public Meal addItems(String ... args){
		Meal meal = new Meal();
		if (args != null) {
			for (String string : args) {
				if (string.equals("鸡肉汉堡")) {
					meal.addItem(new ChickenBurger());
				}else if (string.equals("蔬菜汉堡")) {
					meal.addItem(new VegBurger());
				}else if (string.equals("百事可乐")) {
					meal.addItem(new Pepsi());
				}else if (string.equals("可口可乐")) {
					meal.addItem(new Coke());
				}else {
					meal.addItem(new ZeroI(string));
//					System.out.println("没有"+string+",自动忽略。");
				}
			}
			
			
		}
		
		
		return meal ;
	}
}
