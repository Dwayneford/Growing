package MyJAVA.设计模式.建造者模式BuilderPattern;

public class 总结 {

}
/*

建造模式

1、很多个组员类
2、容器（有个list存放组员，同时有遍历计算组员的方法）
3、容器添加器（向容器自由添加具体的组员，也可生成固定的套餐）（return容器）
4、创建容器添加器，使用容器











*/