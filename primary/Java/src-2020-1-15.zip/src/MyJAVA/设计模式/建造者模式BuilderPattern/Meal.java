package MyJAVA.设计模式.建造者模式BuilderPattern;

import java.util.ArrayList;
import java.util.List;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类.Coke;
import MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类.Pepsi;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.接口.Item;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类.ChickenBurger;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类.VegBurger;
//容器，可以存放组员，并且有遍历计算组员的方法
public class Meal {

	private List<Item> items = new ArrayList<Item>();
	//添加条目方法
	public void addItem (Item item){
		items.add(item);
	}

	
	public void showItems(){
		for (Item item : items) {
			System.out.print("item:"+item.name());
			//item.pack()返回一个packing对象，之后再调用pack()方法
			System.out.print(",pack:"+item.pack().pack()); 
			System.out.println(",price:"+item.price());
		}
		float cost =0.0f;
		for (Item item : items) {
			cost += item.price() ;
		}
		System.out.println("Total Cost:"+cost);
	}
	
	

	public static Meal getAll(){
		Meal meal = new Meal();
		meal.addItem(new ChickenBurger());
		meal.addItem(new Coke());
		meal.addItem(new Pepsi());
		meal.addItem(new VegBurger());
		return meal;
	}

	
	
	
	
}
