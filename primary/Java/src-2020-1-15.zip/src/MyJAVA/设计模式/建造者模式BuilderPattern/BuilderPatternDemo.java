package MyJAVA.设计模式.建造者模式BuilderPattern;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类.Coke;
import MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类.Pepsi;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类.ChickenBurger;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类.VegBurger;

public class BuilderPatternDemo {

	public static void main(String[] args) {
		MealBuilder mealBuilder = new MealBuilder();
		Meal vegMeal = mealBuilder.prepareVegMeal();
		System.out.println("vegMeal=");
		vegMeal.showItems();
		
		Meal nonvMeal = mealBuilder.pripareNonVegMeal();
		System.out.println("\nNonvMeal=");
		nonvMeal.showItems();
		
		Meal multiple =mealBuilder.addItems(new ChickenBurger(),new VegBurger(),new ChickenBurger(),new Pepsi(),new Coke());
		System.out.println("\nmultiple=");
		multiple.showItems();
		
		
		System.out.println("\nmulByName=");
		Meal mulName = mealBuilder.addItems("鸡肉汉堡","鸡肉汉堡","鸡肉汉堡","可口可乐","新疆大盘鸡","蔬菜汉堡","成都冒菜");
//		System.out.println("添加完成");
		mulName.showItems();
		
		System.out.println("\n容器内容创建所有=");
		Meal meal = Meal.getAll();
		
		meal.showItems();
	}
}
