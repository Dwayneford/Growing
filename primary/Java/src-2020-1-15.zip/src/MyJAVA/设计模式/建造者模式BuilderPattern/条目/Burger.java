package MyJAVA.设计模式.建造者模式BuilderPattern.条目;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.Wrapper;
import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.接口.Item;

public abstract class Burger implements Item{



	@Override
	public Packing pack() {
		//汉堡的包装是纸盒
		return new Wrapper();
	}


	public abstract float price();

	
}
