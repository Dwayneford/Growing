package MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.Burger;

public class VegBurger extends Burger{

	@Override
	public String name() {
		return "VegBurger素菜汉堡";
	}

	@Override
	public Packing pack() {
		return super.pack();
	}

	@Override
	public float price() {
		return 25.0f;
	}

}
