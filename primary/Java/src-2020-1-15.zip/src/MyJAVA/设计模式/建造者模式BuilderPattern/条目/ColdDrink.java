package MyJAVA.设计模式.建造者模式BuilderPattern.条目;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.Bottle;
import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.接口.Item;

public abstract class ColdDrink implements Item{

	@Override
	public Packing pack() {
		//装冷饮的是瓶子
		return new Bottle();
	}


	public abstract float price();

}
