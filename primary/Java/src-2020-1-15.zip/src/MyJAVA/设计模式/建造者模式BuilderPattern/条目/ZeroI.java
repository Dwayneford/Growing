package MyJAVA.设计模式.建造者模式BuilderPattern.条目;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.ZeroP;
import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.接口.Item;

public class ZeroI implements Item{
	private String str ;
	public ZeroI(String string) {
		str = string ;
	}

	@Override
	public String name() {

		return "没有‘"+str+"’";
	}

	@Override
	public Packing pack() {

		return new ZeroP();
	}

	@Override
	public float price() {

		return 0;
	}

}
