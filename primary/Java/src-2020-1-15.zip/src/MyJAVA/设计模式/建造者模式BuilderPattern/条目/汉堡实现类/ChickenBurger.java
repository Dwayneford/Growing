package MyJAVA.设计模式.建造者模式BuilderPattern.条目.汉堡实现类;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.Burger;

public class ChickenBurger extends Burger {

	@Override
	public String name() {
		return "ChickenBurger鸡肉汉堡";
	}

	@Override
	public float price() {
		return 50.f;
	}

	@Override
	public Packing pack() {
		return super.pack();
	}

}
