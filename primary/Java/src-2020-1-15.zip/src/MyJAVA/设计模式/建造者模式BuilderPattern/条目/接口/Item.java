package MyJAVA.设计模式.建造者模式BuilderPattern.条目.接口;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;

//条目接口
public interface Item {
	
	public String name() ; //名字
	public Packing pack() ; //包装
	public float price() ; //价格
}
