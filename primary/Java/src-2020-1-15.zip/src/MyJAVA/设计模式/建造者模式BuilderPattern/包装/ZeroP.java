package MyJAVA.设计模式.建造者模式BuilderPattern.包装;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;

public class ZeroP implements Packing{

	@Override
	public String pack() {
		return "空";
	}

}
