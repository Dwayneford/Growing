package MyJAVA.设计模式.建造者模式BuilderPattern.包装;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;

//瓶子
public class Bottle implements Packing {

	@Override
	public String pack() {
		return "Bottle瓶子";
	}

}
