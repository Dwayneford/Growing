package MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口;
//打包接口
public interface Packing {

	public String pack();
}
