package MyJAVA.设计模式.建造者模式BuilderPattern.包装;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;

//纸盒
public class Wrapper implements Packing {

	@Override
	public String pack() {
		return "Wrapper纸盒";
	}

}
