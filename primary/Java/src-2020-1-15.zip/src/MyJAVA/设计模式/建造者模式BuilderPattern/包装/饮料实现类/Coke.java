package MyJAVA.设计模式.建造者模式BuilderPattern.包装.饮料实现类;

import MyJAVA.设计模式.建造者模式BuilderPattern.包装.接口.Packing;
import MyJAVA.设计模式.建造者模式BuilderPattern.条目.ColdDrink;

public class Coke extends ColdDrink{

	@Override
	public String name() {
		return "Coke可口可乐";
	}

	@Override
	public Packing pack() {
		return super.pack();
	}

	@Override
	public float price() {
		return 20.0f;
	}

	
}
