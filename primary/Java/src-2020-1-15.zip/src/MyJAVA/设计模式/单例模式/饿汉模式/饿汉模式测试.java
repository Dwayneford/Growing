package MyJAVA.设计模式.单例模式.饿汉模式;

public class 饿汉模式测试 {

	public static void main(String[] args) {
		//不能new，因为构造器私有
		Singleton s = Singleton.getinstance();
		s.say();
	}
}
