package MyJAVA.设计模式.过滤器模式;

import java.util.ArrayList;
import java.util.List;

import MyJAVA.设计模式.过滤器模式.过滤器实体类.ConbineFilter;
import MyJAVA.设计模式.过滤器模式.过滤器实体类.FemaleFilter;
import MyJAVA.设计模式.过滤器模式.过滤器实体类.MaleFilter;
import MyJAVA.设计模式.过滤器模式.过滤器实体类.SingleFilter;

public class FilterPatternDemo {
	public static void main(String[] args) {
		List<Person> persons = new ArrayList<Person>();
		
		persons.add(new Person("Robert","Male", "Single"));
		persons.add(new Person("John","Male", "Married"));
		persons.add(new Person("Laura","Female", "Married"));
		persons.add(new Person("Diana","Female", "Single"));
		persons.add(new Person("Mike","Male", "Single"));
		persons.add(new Person("Bobby","Male", "Single"));
		
		Criteria male = new MaleFilter();
		Criteria female = new FemaleFilter();
		Criteria single = new SingleFilter();	  
		Criteria singleFemal = new ConbineFilter(female, single);
		Criteria singleMale = new ConbineFilter(male, single);	
		
		System.out.println("Males: ");	
		printPersons(male.FilterCriteria(persons));
		
		System.out.println("\nFemales: ");
		printPersons(female.FilterCriteria(persons));
		//结合过滤，单亲女性
		System.out.println("\nsingleFemal: ");
		printPersons(singleFemal.FilterCriteria(persons));
		//结合过滤，单亲男性
		System.out.println("\nsinglemale: ");
		printPersons(singleMale.FilterCriteria(persons));
		
		
		
	}
	
	public static void printPersons(List<Person> persons){
		for (Person person : persons) {
			System.out.println("Person : [ Name : " + person.getName() 
            +", Gender : " + person.getGender() 
            +", Marital Status : " + person.getMaritalStatus()
            +" ]");
		}
		
		
	}
	
	
}
