package MyJAVA.设计模式.过滤器模式.过滤器实体类;

import java.util.ArrayList;
import java.util.List;

import MyJAVA.设计模式.过滤器模式.Criteria;
import MyJAVA.设计模式.过滤器模式.Person;

public class ConbineFilter implements Criteria{

	private Criteria filterOne ;
	private Criteria filterTwo ;
	
	public ConbineFilter(Criteria filterOne, Criteria filterTwo) {
		super();
		this.filterOne = filterOne;
		this.filterTwo = filterTwo;
	}

	@Override
	public List<Person> FilterCriteria(List<Person> persionList) {
		List<Person> filterOneList = filterOne.FilterCriteria(persionList);
		return filterTwo.FilterCriteria(filterOneList);
	}

}
