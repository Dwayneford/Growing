package MyJAVA.设计模式.过滤器模式.过滤器实体类;

import java.util.ArrayList;
import java.util.List;

import MyJAVA.设计模式.过滤器模式.Criteria;
import MyJAVA.设计模式.过滤器模式.Person;

public class SingleFilter implements Criteria{

	@Override
	public List<Person> FilterCriteria(List<Person> persionList) {
		List<Person> singleList = new ArrayList<Person>();
		for (Person person : persionList) {
			if (person.getMaritalStatus().equalsIgnoreCase("single")) {
				singleList.add(person);
			}
		}
		return singleList;
	}

}
