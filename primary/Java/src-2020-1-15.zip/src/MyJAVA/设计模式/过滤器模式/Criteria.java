package MyJAVA.设计模式.过滤器模式;

import java.util.List;

public interface Criteria {
	public List<Person> FilterCriteria(List<Person> persionList);
}
