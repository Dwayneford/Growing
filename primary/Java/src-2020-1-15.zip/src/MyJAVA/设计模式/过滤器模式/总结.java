package MyJAVA.设计模式.过滤器模式;

public class 总结 {

}
/*

过滤器模式
过滤器：输入list ，输出list
结合过滤器，方法内部再加过滤





*/