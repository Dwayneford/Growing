package MyJAVA.JAVA_01环境配置;

public class JAVA配置 {
/**
 * 发斯蒂芬
 */
}
/*

1、Java的核心优势是跨平台，Java虚拟机是实现跨平台的关键

2、各个版本：
	JavaSE(Java Standard Edition)：标准版，定位在个人计算机上的应用。
	JavaEE(Java Enterprise Edition)：企业版，定位在服务器端的应用。
	JavaME(Java Micro Edition)：微型版，定位在消费性电子产品的应用上
3、Java的特性和优势
	·跨平台/可移植性
	·安全性
	·面向对象
	·简单性
	·高性能（虚拟机）
	·分布式
	·多线程
	·健壮性
4、运行机制
	1编写Java源文件（.java）
	2利用编译器（javac）编译成字节码文件（.class）
	3虚拟机（解释器）解释执行
5、JVM、JRE和JDK
	JVM(Java Virtual Machine)负责将字节码文件解释运行，不同的平台有不同的虚拟机。
	Java Runtime Environment (JRE)包含：Java虚拟机、库函数、运行Java应用程序所必须的文件。
	Java Development Kit (JDK)包含：包含JRE，以及增加编译器和调试器等用于程序开发的文件。
6、










 
*/