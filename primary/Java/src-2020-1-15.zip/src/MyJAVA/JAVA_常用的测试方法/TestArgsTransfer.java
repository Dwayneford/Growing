package MyJAVA.JAVA_常用的测试方法;
/**
 *	参数的传值机制测试
 * @author Administrator
 *传递一个对象和传递一个基本数据类型的值不一样
 */
public class TestArgsTransfer {

	public static void main(String[] args) {
		TestArgsTransfer tt = new TestArgsTransfer();
		int i=10;
        int j=20;
        System.out.println("基本数据类型值传递(前):i="+i+";j="+j);
		tt.swap(i, j);
		System.out.println("基本数据类型值传递(后):i="+i+";j="+j);
		System.out.println();
		
		SwapOBJ obj = new SwapOBJ();
		System.out.println("引用数据类型值传递(前):obj.i="+obj.i+";obj.j="+obj.j);
		tt.swap(obj);
		System.out.println("引用数据类型值传递(后):obj.i="+obj.i+";obj.j="+obj.j);
		
	}
	//定义一个方法，交换两个变量的值
    public void swap(int a,int b){
        int temp=a;
        a=b;
        b=temp;
        System.out.println("方法内部:i="+a+";b="+b);
    }
  //交换元素的值
    public void swap(SwapOBJ dataSwap){
        int temp=dataSwap.i;
        dataSwap.i=dataSwap.j;
        dataSwap.j=temp;
        System.out.println("方法内部:obj.i="+dataSwap.i+";obj.b="+dataSwap.j);
    }
}
class SwapOBJ{
    int i=10;
    int j=20;
}




