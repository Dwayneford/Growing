package JAVA框架;



public class _01_Struts2框架 {

}
/*

Struts2它本质上相当于一个servlet

与Servlet对比

	优点：业务代码解耦，提高开发效率。提供了对MVC的一个清晰的实现，这
		一实现包含了很多参与对所以请求进行处理的关键组件，如：拦截器、OGNL表达式语言、堆栈。

	缺点：执行效率偏低，需要使用反射、解析XML等技术手段，结构复杂
所需包:
commons-fileupload-x.y.z.jar
commons-io-x.y.z.jar
commons-lang-x.y.jar
commons-logging-x.y.z.jar
commons-logging-api-x.y.jar
freemarker-x.y.z.jar
javassist-x.y.z.GA
ognl-x.y.z.jar
struts2-core-x.y.z.jar
xwork-core.x.y.z.jar



1、action类继承actionsupport(属性须有set和get)
2、struts.xml
3、web.xml
3、jsp视图


ActionContext.getContext().put(k,v);





1、configur facets 
2、Struts2
3、web.xml， strus.xml
4、action类，返回关键字，
<package name="p1" extends="struts-default,json-default" namespace="/">
	<action name="test" class="com.Test" method="">
<!-- 页面传入web-Struts-类-方法-返回值-根据值跳转 --!>
		<result name="关键字">success.jsp</result>	
		<result name="ok">main.jsp</result>
	</action>	
</package>
5、"test!login.action" ，通配符：test_* method={1}
6、4种type如下：
	dispatcher:result type默认的类型，相当于servlet的foward方式跳转页面。客户端看到的是struts2中配置的地址，而不是真正页面的地址，一般用于跳转到jsp页面,页面能拿到值 
	redirect:页面重定向，客户端跳转，数据全部丢失，地址栏发生变化，页面不能拿到值 
	chain:将请求转发给一个Action，Action能通过getAttribute(“uname”)拿到值 
	redirect-action:一般用于跳转到Action，Action不能通过getAttribute(“uname”)拿到值
	
	传值给jsp：
	<result type="redirect-action">/success.jsp</result>
	
	传值给Action：
	<result type="redirect-action">/TestAction</result>

7、异常:
<exception-mapping result="exception1" exception="java.lang.ArithmeticException"></exception-mapping>
<result name="exception" >/errorone.jsp</result>






<action name="login" class="com.yc123.action.LoginAction">
			
			<!-- 跳转页面 -->
			<result name="success">/success.jsp</result>
			<!-- <result name="ok">/main.jsp</result> -->
		</action>
		
		<!-- 使用统配符 拼接访问方法 -->
		<action name="login_*" class="com.yc123.action.LoginAction" method="{1}">
			<!-- 
				type="dispatcher" 默认界面跳转方式，可以 传递请求参数，地址栏不会改变
					  redirect 外部跳转 地址栏 发送改变，不能携带请求参数
					  
					  redirectAction 外部跳转到action中，不能携带参数；
					  
					  chain:内部跳转到action中，将多个action链接起来，使用同一个http请求，
						共享同一个ActionContext 可以传递参数；
			 -->
			
			<result name="exist" type="dispatcher">/index.jsp</result>
			
			<result name="ok" type="redirectAction">user_userList.action</result>
			
			<result name="updateUser" type="redirect">user_editUser.action?userId=${upUserId}</result>
			
			<!-- <result name="" type="redirectAction">
				<param name="actionName">user_editUser.action</param>
				<param name="userId">${upUserId}</param>
			</result> -->
			
			<result name="logForUser" type="chain">user_addUser</result>
		</action>
		
		<!-- 用户action -->
		<action name="user_*" class="com.yc123.action.UserAction" method="{1}" >
			<result name="userList">/userlist.jsp</result>
			<result name="editUser">/editUser.jsp</result>
			<result name="addUser">/editUser.jsp</result>
		</action>





文件上传总结

页面：
引入标签：
	<%@ taglib prefix="s" uri="/struts-tags"%>
上传表单
   <form action="upload" method="post" enctype="multipart/form-data">
      <label for="myFile">Upload your file</label>
      <input type="file" name="myFile" />
      <input type="submit" value="Upload"/>
   </form>

	<br>strust2文件上传成功！${uploadFileName }

后台：
3个属性
action：
   private File myFile; 名称与页面name相同
   private String *ContentType;
   private String *FileName;
方法：
1、文件保存路径
2、创建文件File file = new File(“路径”, “文件名：myFile”);
3、复制文件FileUtils.copyFile(upload, file);

配置文件

	<constant name="struts.devMode" value="true"></constant>
	<constant name="struts.multipart.maxSize" value="102400"></constant>
	
	<package name="pk" extends="struts-default" namespace="/">
		<action name="up" class="com.action.UploadAction" method="uploadFile">		
			<!-- <interceptor-ref name="basicStack"></interceptor-ref>
	       <interceptor-ref name="fileUpload">
	           <param name="allowedTypes">image/jpg,image/gif</param>
	       </interceptor-ref> -->
	       
			<result name="success">/successupload.jsp</result>
			<result name="error">/errorupload.jsp</result>		
		</action>
	</package>

*/