package JAVA框架.hibernate;

public class _02_hibernate框架 {

}
/*


1、在database explorer内新建一个数据库连接；
2、configure facets 内构建hibernate环境；
3、数据库连接里选择待导出的表，用hibernate reverse engineering 将其转化为实体类




1.概念：Hibernate是持久层（数据访问层）的框架，对JDBC进行了封装，是对数据库访问提出的面向对象的解决方案。

2.作用：使用Hibernate可以直接访问对象，Hibernate自动将访问转换成SQL执行，从而实现简介访问数据库的目的，
简化了数据访问层的代码开发。

工作原理:
读取并解析配置文件
读取并解析映射信息，创建SessionFactory
打开Sesssion
创建事务Transation
持久化操作
提交事务
关闭Session
关闭SesstionFactory






*/